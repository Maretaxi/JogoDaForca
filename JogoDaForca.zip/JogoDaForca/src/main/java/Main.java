import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 * JOGO DA FORCA - arquitetura monolítica.
 * Todo o sistema (controller, service, repository e modelo) fica em um único
 * arquivo e roda como um único executável.
 */

// ---------- Palavra ----------
class Palavra {

    private String texto;

    public Palavra(String texto) {
        this.texto = texto.toLowerCase();
    }

    public String getTexto() {
        return texto;
    }
}


// ---------- PalavraRepository ----------
/** Banco de palavras (um Array), como no diagrama de contêineres. */
class PalavraRepository {

    private static final String[] PALAVRAS = {
        "java", "classe", "objeto", "metodo", "heranca", "interface",
        "servico", "arquitetura", "componente", "teste", "software"
    };

    private final Random random = new Random();

    // Dependência: só cria e devolve uma Palavra, sem guardá-la.
    public Palavra buscarPalavraAleatoria() {
        return new Palavra(PALAVRAS[random.nextInt(PALAVRAS.length)]);
    }
}


// ---------- PalavraService ----------
class PalavraService {

    private final PalavraRepository repository = new PalavraRepository();

    public Palavra sortearPalavra() {
        return repository.buscarPalavraAleatoria();
    }
}


// ---------- Forca ----------
class Forca {

    public static final int MAX_ERROS = 6;

    private int errosDesenhados;

    public void desenharProximaParte() {
        if (errosDesenhados < MAX_ERROS) {
            errosDesenhados++;
        }
    }

    /** Devolve o desenho da forca de acordo com os erros. */
    public String desenho() {
        String cabeca = errosDesenhados >= 1 ? "O" : " ";
        String corpo = errosDesenhados >= 2 ? "|" : " ";
        String bracoE = errosDesenhados >= 3 ? "/" : " ";
        String bracoD = errosDesenhados >= 4 ? "\\" : " ";
        String pernaE = errosDesenhados >= 5 ? "/" : " ";
        String pernaD = errosDesenhados >= 6 ? "\\" : " ";
        return "  +---+\n"
             + "  |   |\n"
             + "  |   " + cabeca + "\n"
             + "  |  " + bracoE + corpo + bracoD + "\n"
             + "  |  " + pernaE + " " + pernaD + "\n"
             + "  |\n"
             + "=========";
    }
}


// ---------- TentativaLetra ----------
class TentativaLetra {

    private char letra;

    public TentativaLetra(char letra) {
        this.letra = letra;
    }

    public char getLetra() {
        return letra;
    }
}


// ---------- Jogo ----------
class Jogo {

    private int tentativasRestantes = Forca.MAX_ERROS;
    private List<Character> letrasDescobertas = new ArrayList<>();

    private final Palavra palavra;                                  // associação
    private final Forca forca = new Forca();                        // composição
    private final List<TentativaLetra> tentativas = new ArrayList<>(); // composição 0..*

    public Jogo(Palavra palavra) {
        this.palavra = palavra;
    }

    /** Retorna true se a letra existe na palavra. */
    public boolean tentarLetra(char letra) {
        letra = Character.toLowerCase(letra);
        tentativas.add(new TentativaLetra(letra));

        if (palavra.getTexto().indexOf(letra) >= 0) {
            if (!letrasDescobertas.contains(letra)) {
                letrasDescobertas.add(letra);
            }
            return true;
        }
        tentativasRestantes--;
        forca.desenharProximaParte();
        return false;
    }

    public boolean venceu() {
        for (char c : palavra.getTexto().toCharArray()) {
            if (!letrasDescobertas.contains(c)) {
                return false;
            }
        }
        return true;
    }

    public boolean perdeu() {
        return tentativasRestantes <= 0;
    }

    public boolean jaTentou(char letra) {
        letra = Character.toLowerCase(letra);
        for (TentativaLetra t : tentativas) {
            if (t.getLetra() == letra) {
                return true;
            }
        }
        return false;
    }

    public String getPalavraMascarada() {
        StringBuilder sb = new StringBuilder();
        for (char c : palavra.getTexto().toCharArray()) {
            sb.append(letrasDescobertas.contains(c) ? c : '_').append(' ');
        }
        return sb.toString().trim();
    }

    public String getLetrasTentadas() {
        StringBuilder sb = new StringBuilder();
        for (TentativaLetra t : tentativas) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            sb.append(t.getLetra());
        }
        return sb.length() == 0 ? "nenhuma" : sb.toString();
    }

    public String getPalavraSecreta() { return palavra.getTexto(); }
    public int getTentativasRestantes() { return tentativasRestantes; }
    public Forca getForca() { return forca; }
}


// ---------- JogoService ----------
class JogoService {

    private Jogo jogoAtual;
    private final PalavraService palavraService = new PalavraService();

    public Jogo iniciarPartida() {
        Palavra palavra = palavraService.sortearPalavra();
        jogoAtual = new Jogo(palavra);
        return jogoAtual;
    }

    public String processarTentativa(char letra) {
        if (jogoAtual == null) {
            return "Nenhuma partida em andamento.";
        }
        if (!Character.isLetter(letra)) {
            return "Digite apenas uma letra.";
        }
        if (jogoAtual.jaTentou(letra)) {
            return "Você já tentou a letra '" + letra + "'.";
        }

        boolean acertou = jogoAtual.tentarLetra(letra);

        if (jogoAtual.venceu()) {
            return "Parabéns, você venceu! A palavra era: " + jogoAtual.getPalavraSecreta();
        }
        if (jogoAtual.perdeu()) {
            return "Você perdeu! A palavra era: " + jogoAtual.getPalavraSecreta();
        }
        return acertou ? "Acertou!" : "Errou!";
    }

    public Jogo getJogoAtual() { return jogoAtual; }
}


// ---------- JogoController ----------
class JogoController {

    private final JogoService service = new JogoService();

    public void iniciarJogo() {
        Jogo jogo = service.iniciarPartida();
        System.out.println("=== JOGO DA FORCA ===");
        mostrarTela(jogo);
    }

    public void tentarLetra(char letra) {
        String resultado = service.processarTentativa(letra);
        System.out.println("\n>> " + resultado);
        mostrarTela(service.getJogoAtual());
    }

    public boolean partidaEmAndamento() {
        Jogo j = service.getJogoAtual();
        return j != null && !j.venceu() && !j.perdeu();
    }

    private void mostrarTela(Jogo jogo) {
        System.out.println(jogo.getForca().desenho());
        System.out.println("Palavra: " + jogo.getPalavraMascarada());
        System.out.println("Tentativas restantes: " + jogo.getTentativasRestantes());
        System.out.println("Letras tentadas: " + jogo.getLetrasTentadas());
    }
}


// ---------- Main (Terminal App) ----------
/** Tela de terminal do Jogo da Forca (arquitetura monolítica). */
public class Main {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        JogoController controller = new JogoController();
        String continuar;

        do {
            controller.iniciarJogo();
            while (controller.partidaEmAndamento()) {
                System.out.print("\nDigite uma letra: ");
                String linha = entrada.nextLine().trim();
                if (linha.isEmpty()) {
                    continue;
                }
                controller.tentarLetra(linha.charAt(0));
            }
            System.out.print("\nJogar novamente? (s/n): ");
            continuar = entrada.nextLine().trim().toLowerCase();
        } while (continuar.equals("s"));

        System.out.println("Até a próxima!");
    }
}
