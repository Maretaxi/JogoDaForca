package br.fatec.listatarefas.tarefas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/** Testes da entidade Tarefa. */
class TarefaTest {

    @Test
    @DisplayName("CT-15 (RN-04): tarefa criada guarda id e descrição e nasce não concluída")
    void criaTarefaNaoConcluida() {
        Tarefa t = new Tarefa(3, "Ler capítulo 2", false);
        assertAll(
                () -> assertEquals(3, t.getId()),
                () -> assertEquals("Ler capítulo 2", t.getDescricao()),
                () -> assertFalse(t.isConcluida()));
    }

    @Test
    @DisplayName("CT-16 (RF-03): marcarConcluida é idempotente")
    void marcarConcluidaIdempotente() {
        Tarefa t = new Tarefa(1, "A", false);
        t.marcarConcluida();
        t.marcarConcluida();
        assertTrue(t.isConcluida());
    }

    @Test
    @DisplayName("CT-17 (RF-02): toString mostra [x] para concluída e [ ] para pendente")
    void formataParaExibicao() {
        assertEquals("1 - [ ] A", new Tarefa(1, "A", false).toString());
        assertEquals("2 - [x] B", new Tarefa(2, "B", true).toString());
    }
}
