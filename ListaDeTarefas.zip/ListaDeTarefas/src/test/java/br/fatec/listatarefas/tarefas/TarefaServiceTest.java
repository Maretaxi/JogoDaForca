package br.fatec.listatarefas.tarefas;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

/** Testes da classe TarefaService (regras de negócio RN-01 a RN-04). */
class TarefaServiceTest {

    @TempDir
    Path pasta;

    private String arquivo;
    private TarefaService service;

    @BeforeEach
    void preparar() {
        arquivo = pasta.resolve("Lista de tarefas.txt").toString();
        service = new TarefaService(new TarefaRepository(arquivo));
    }

    @Test
    @DisplayName("CT-01 (RF-01): adicionar tarefa válida")
    void adicionaTarefaValida() {
        Tarefa t = service.criar("Estudar UML");
        assertEquals(1, t.getId());
        assertFalse(t.isConcluida());
        assertEquals(1, service.listarTodas().size());
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"   ", "\t"})
    @DisplayName("CT-02 (RN-01): descrição vazia é rejeitada")
    void rejeitaDescricaoVazia(String descricao) {
        assertThrows(IllegalArgumentException.class, () -> service.criar(descricao));
        assertTrue(service.listarTodas().isEmpty());
    }

    @Test
    @DisplayName("CT-03 (RF-02): listar tarefas persistidas, na ordem de criação")
    void listaTarefasPersistidas() {
        service.criar("A");
        service.criar("B");
        List<Tarefa> lista = service.listarTodas();
        assertEquals(2, lista.size());
        assertEquals("A", lista.get(0).getDescricao());
        assertEquals(2, lista.get(1).getId());
    }

    @Test
    @DisplayName("CT-04 (RF-03): concluir tarefa grava no arquivo")
    void concluiTarefa() {
        service.criar("A");
        service.concluir(1);
        assertTrue(service.listarTodas().get(0).isConcluida());
    }

    @Test
    @DisplayName("CT-05 (RN-03): concluir id inexistente falha")
    void naoConcluiIdInexistente() {
        assertThrows(IllegalArgumentException.class, () -> service.concluir(99));
    }

    @ParameterizedTest
    @ValueSource(strings = {"a|b", "linha1\nlinha2", "linha1\rlinha2"})
    @DisplayName("CT-06 (RN-02): descrição com '|' ou quebra de linha é rejeitada")
    void rejeitaCaracteresProibidos(String descricao) {
        assertThrows(IllegalArgumentException.class, () -> service.criar(descricao));
    }

    @Test
    @DisplayName("CT-07 (RN-02): valor limite — 100 caracteres aceita, 101 rejeita")
    void respeitaLimiteDeTamanho() {
        assertDoesNotThrow(() -> service.criar("x".repeat(100)));
        assertThrows(IllegalArgumentException.class, () -> service.criar("x".repeat(101)));
        assertEquals(1, service.listarTodas().size());
    }

    @Test
    @DisplayName("CT-08 (RN-04): novo id = maior id existente + 1")
    void geraIdAPartirDoMaior() {
        TarefaRepository repo = new TarefaRepository(arquivo);
        repo.salvar(new Tarefa(1, "A", false));
        repo.salvar(new Tarefa(5, "B", true));
        Tarefa nova = service.criar("C");
        assertEquals(6, nova.getId());
        assertFalse(nova.isConcluida());
    }

    @Test
    @DisplayName("CT-09 (RNF-01): operações com 1.000 tarefas em até 1 segundo")
    void desempenhoComMilTarefas() {
        List<String> linhas = new ArrayList<>();
        for (int i = 1; i <= 1000; i++) {
            linhas.add(i + "|false|Tarefa " + i);
        }
        new ListaDeTarefas(arquivo).gravarLinhas(linhas);

        assertTimeout(Duration.ofSeconds(1), () -> {
            assertEquals(1000, service.listarTodas().size());
            service.criar("Mais uma");
            service.concluir(500);
        });
    }

    @Test
    @DisplayName("CT-10 (RNF-02): dados continuam após 'reabrir' o app")
    void dadosPersistemAposReabrir() {
        service.criar("A");
        service.concluir(1);
        TarefaService reaberto = new TarefaService(new TarefaRepository(arquivo));
        Tarefa t = reaberto.listarTodas().get(0);
        assertEquals("A", t.getDescricao());
        assertTrue(t.isConcluida());
    }
}
