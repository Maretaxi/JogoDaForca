package br.fatec.listatarefas.tarefas;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.stream.Collectors;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/**
 * Testes da tela gráfica (TelaTarefas.fxml + TelaTarefasFxController).
 * Precisam de uma tela (display); em máquinas sem tela, são pulados.
 */
class TelaGraficaTest {

    private static boolean temTela;

    @TempDir
    Path pasta;

    private TelaTarefasFxController tela;
    private Parent raiz;
    private TextField campo;
    private ListView<Tarefa> lista;
    private Label mensagem;
    private Label resumo;
    private Button botaoConcluir;
    private Button botaoExcluir;

    @BeforeAll
    static void iniciarJavaFx() throws Exception {
        CountDownLatch pronto = new CountDownLatch(1);
        try {
            Platform.startup(pronto::countDown);
            temTela = pronto.await(10, TimeUnit.SECONDS);
            Platform.setImplicitExit(false);     // fechar a janela de um teste não encerra o JavaFX
        } catch (IllegalStateException jaIniciado) {
            temTela = true;
            Platform.setImplicitExit(false);
        } catch (Throwable semTela) {
            temTela = false;
        }
    }

    /** Executa no thread do JavaFX e espera terminar. */
    private static void naTela(Runnable acao) throws Exception {
        AtomicReference<Throwable> erro = new AtomicReference<>();
        CountDownLatch fim = new CountDownLatch(1);
        Platform.runLater(() -> {
            try {
                acao.run();
            } catch (Throwable t) {
                erro.set(t);
            } finally {
                fim.countDown();
            }
        });
        assertTrue(fim.await(10, TimeUnit.SECONDS), "a tela não respondeu");
        if (erro.get() != null) {
            throw new AssertionError(erro.get());
        }
    }

    @SuppressWarnings("unchecked")
    @BeforeEach
    void abrirTela() throws Exception {
        assumeTrue(temTela, "sem tela (display) para o JavaFX");
        String arquivo = pasta.resolve("t.txt").toString();
        TarefaController controller = new TarefaController(new TarefaService(new TarefaRepository(arquivo)));
        naTela(() -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource(
                        "/br/fatec/listatarefas/tarefas/TelaTarefas.fxml"));
                raiz = loader.load();
                tela = loader.getController();
                campo = (TextField) loader.getNamespace().get("campoDescricao");
                lista = (ListView<Tarefa>) loader.getNamespace().get("listaTarefas");
                mensagem = (Label) loader.getNamespace().get("mensagem");
                resumo = (Label) loader.getNamespace().get("resumo");
                botaoConcluir = (Button) loader.getNamespace().get("botaoConcluir");
                botaoExcluir = (Button) loader.getNamespace().get("botaoExcluir");
                tela.inicializar(controller);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
    }

    private List<String> itens() {
        return lista.getItems().stream().map(Tarefa::toString).toList();
    }

    @Test
    @DisplayName("CT-26 (RF-02): a tela abre a partir do FXML, com a lista vazia")
    void abreComListaVazia() {
        assertNotNull(tela);
        assertTrue(lista.getItems().isEmpty());
        assertEquals("", mensagem.getText());
    }

    @Test
    @DisplayName("CT-27 (RF-01): digitar e clicar em Adicionar mostra a tarefa e limpa o campo")
    void adicionaPelaTela() throws Exception {
        naTela(() -> {
            campo.setText("Estudar UML");
            tela.adicionar();
        });
        assertEquals(List.of("1 - [ ] Estudar UML"), itens());
        assertEquals("", campo.getText());
    }

    @Test
    @DisplayName("CT-28 (RN-01, RNF-05): Adicionar com o campo vazio mostra o erro na tela")
    void erroDeDescricaoVazia() throws Exception {
        naTela(() -> tela.adicionar());
        assertEquals("Erro: A descrição da tarefa não pode ser vazia.", mensagem.getText());
        assertTrue(lista.getItems().isEmpty());
    }

    @Test
    @DisplayName("CT-29 (RF-03): selecionar a tarefa e clicar em Marcar como concluída")
    void concluiPelaTela() throws Exception {
        naTela(() -> {
            campo.setText("A");
            tela.adicionar();
            lista.getSelectionModel().select(0);
            tela.concluir();
        });
        assertEquals(List.of("1 - [x] A"), itens());
    }

    @Test
    @DisplayName("CT-30 (RN-03, RNF-05): concluir sem selecionar tarefa mostra o erro")
    void concluirSemSelecao() throws Exception {
        naTela(() -> tela.concluir());
        assertEquals("Erro: selecione ou informe a tarefa.", mensagem.getText());
    }

    @Test
    @DisplayName("CT-31 (RNF-04): acentos digitados na tela gráfica são preservados")
    void acentosNaTela() throws Exception {
        naTela(() -> {
            campo.setText("Revisão de Programação");
            tela.adicionar();
        });
        assertEquals(List.of("1 - [ ] Revisão de Programação"), itens());
    }

    @Test
    @DisplayName("CT-37 (RF-04): selecionar a tarefa e clicar em Excluir")
    void excluiPelaTela() throws Exception {
        naTela(() -> {
            campo.setText("A");
            tela.adicionar();
            campo.setText("B");
            tela.adicionar();
            lista.getSelectionModel().select(0);
            tela.excluir();
        });
        assertEquals(List.of("2 - [ ] B"), itens());
    }

    @Test
    @DisplayName("CT-38 (RN-03, RNF-05): excluir sem selecionar tarefa mostra o erro")
    void excluirSemSelecao() throws Exception {
        naTela(() -> tela.excluir());
        assertEquals("Erro: selecione ou informe a tarefa.", mensagem.getText());
        assertTrue(mensagem.isVisible());
    }

    @Test
    @DisplayName("CT-39 (RF-02): o cabeçalho resume total, concluídas e pendentes")
    void resumoNoCabecalho() throws Exception {
        assertEquals("Nenhuma tarefa", resumo.getText());
        naTela(() -> {
            campo.setText("A");
            tela.adicionar();
            campo.setText("B");
            tela.adicionar();
            lista.getSelectionModel().select(0);
            tela.concluir();
        });
        assertEquals("2 tarefas · 1 concluída · 1 pendente", resumo.getText());
    }

    @Test
    @DisplayName("CT-40 (RNF-05): Concluir e Excluir ficam desabilitados sem tarefa selecionada")
    void botoesDependemDaSelecao() throws Exception {
        assertTrue(botaoConcluir.isDisabled());
        assertTrue(botaoExcluir.isDisabled());
        naTela(() -> {
            campo.setText("A");
            tela.adicionar();
            lista.getSelectionModel().select(0);
        });
        assertFalse(botaoConcluir.isDisabled());
        assertFalse(botaoExcluir.isDisabled());
    }

    @Test
    @DisplayName("CT-41 (RF-02, RF-03): na janela, cada tarefa aparece com selo Pendente/Concluída e concluída riscada")
    void aparenciaDasTarefasNaJanela() throws Exception {
        Stage[] janela = new Stage[1];
        naTela(() -> {
            campo.setText("A");
            tela.adicionar();
            campo.setText("B");
            tela.adicionar();
            lista.getSelectionModel().select(0);
            tela.concluir();
            janela[0] = new Stage();
            janela[0].setScene(new Scene(raiz));
            janela[0].show();
            raiz.applyCss();
            raiz.layout();
        });
        AtomicReference<String> selos = new AtomicReference<>();
        AtomicReference<Integer> riscadas = new AtomicReference<>();
        naTela(() -> {
            selos.set(raiz.lookupAll(".selo").stream()
                    .map(n -> ((Label) n).getText()).collect(Collectors.joining(",")));
            riscadas.set(raiz.lookupAll(".item-texto.concluida").size());
            janela[0].hide();
        });
        assertEquals("Concluída,Pendente", selos.get());
        assertEquals(1, riscadas.get());
    }
}
