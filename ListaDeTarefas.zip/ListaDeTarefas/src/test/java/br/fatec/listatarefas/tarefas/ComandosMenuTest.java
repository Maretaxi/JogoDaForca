package br.fatec.listatarefas.tarefas;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Testes do padrão Command: TelaTarefas (Invoker) + comandos concretos. */
class ComandosMenuTest {

    @TempDir
    Path pasta;

    private TarefaController controller;
    private ByteArrayOutputStream bufferSaida;

    @BeforeEach
    void preparar() {
        String arquivo = pasta.resolve("t.txt").toString();
        controller = new TarefaController(new TarefaService(new TarefaRepository(arquivo)));
        bufferSaida = new ByteArrayOutputStream();
    }

    private String rodarTela(String digitado) {
        TelaTarefas tela = new TelaTarefas(controller,
                new ByteArrayInputStream(digitado.getBytes(StandardCharsets.UTF_8)),
                new PrintStream(bufferSaida, true, StandardCharsets.UTF_8));
        tela.iniciar();
        return bufferSaida.toString(StandardCharsets.UTF_8);
    }

    @Test
    @DisplayName("CT-20 (RF-01): opção 1 executa NovaTarefaComando e mostra a tarefa")
    void novaTarefaPeloMenu() {
        String saida = rodarTela("1\nComprar pão\n0\n");
        assertTrue(saida.contains("1 - [ ] Comprar pão"));
        assertEquals(1, controller.carregarTarefas().size());
    }

    @Test
    @DisplayName("CT-21 (RNF-05): opção inválida mostra mensagem e o menu continua")
    void opcaoInvalida() {
        String saida = rodarTela("9\n0\n");
        assertTrue(saida.contains("Opção inválida."));
        assertTrue(saida.contains("Até logo!"));
    }

    @Test
    @DisplayName("CT-22 (RNF-05, RN-03): concluir com texto ou id inexistente mostra erro")
    void concluirComEntradaInvalida() {
        String saida = rodarTela("3\nabc\n3\n42\n0\n");
        assertTrue(saida.contains("Erro: informe um número válido."));
        assertTrue(saida.contains("Erro: Tarefa 42 não encontrada."));
    }

    @Test
    @DisplayName("CT-23 (RNF-03): novo comando registrado entra no menu sem mudar o Invoker")
    void registraNovoComando() {
        TelaTarefas tela = new TelaTarefas(controller,
                new ByteArrayInputStream("5\n0\n".getBytes(StandardCharsets.UTF_8)),
                new PrintStream(bufferSaida, true, StandardCharsets.UTF_8));
        boolean[] executou = {false};
        tela.registrar("5", new ComandoMenu() {
            public String descricao() { return "Comando de teste"; }
            public void executar() { executou[0] = true; }
        });
        tela.iniciar();
        assertTrue(executou[0]);
        assertTrue(bufferSaida.toString(StandardCharsets.UTF_8).contains("5 - Comando de teste"));
    }

    @Test
    @DisplayName("CT-25 (RNF-04): acentos digitados em Windows-1252 são lidos corretamente")
    void leAcentosNaCodificacaoDoWindows() {
        Charset windows = Charset.forName("windows-1252");
        TelaTarefas tela = new TelaTarefas(controller,
                new ByteArrayInputStream("1\nAção\n0\n".getBytes(windows)),
                new PrintStream(bufferSaida, true, StandardCharsets.UTF_8), windows);
        tela.iniciar();
        assertEquals("Ação", controller.carregarTarefas().get(0).getDescricao());
    }

    @Test
    @DisplayName("CT-36 (RF-04, RN-03): opção 4 do console exclui a tarefa e avisa id inexistente")
    void excluiPeloConsole() {
        String saida = rodarTela("1\nA\n1\nB\n4\n1\n4\n7\n0\n");
        assertEquals(1, controller.carregarTarefas().size());
        assertEquals("B", controller.carregarTarefas().get(0).getDescricao());
        assertTrue(saida.contains("4 - Excluir tarefa"));
        assertTrue(saida.contains("Erro: Tarefa 7 não encontrada."));
    }
}
