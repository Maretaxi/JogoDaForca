package br.fatec.listatarefas.tarefas;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Testes da classe ListaDeTarefas (leitura e gravação do arquivo .txt). */
class ListaDeTarefasTest {

    @TempDir
    Path pasta;

    @Test
    @DisplayName("CT-18 (R-01): arquivo inexistente é lido como lista vazia")
    void arquivoInexistenteViraListaVazia() {
        ListaDeTarefas lista = new ListaDeTarefas(pasta.resolve("nao-existe.txt").toString());
        assertTrue(lista.lerLinhas().isEmpty());
    }

    @Test
    @DisplayName("CT-19 (RNF-04): grava e lê em UTF-8, preservando acentos")
    void preservaAcentosEmUtf8() {
        ListaDeTarefas lista = new ListaDeTarefas(pasta.resolve("t.txt").toString());
        List<String> linhas = List.of("1|false|Revisão de Programação", "2|true|Ação nº 2");
        lista.gravarLinhas(linhas);
        assertEquals(linhas, lista.lerLinhas());
    }
}
