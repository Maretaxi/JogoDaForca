package br.fatec.listatarefas.tarefas;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Testes da classe TarefaRepository (conversão linha <-> Tarefa). */
class TarefaRepositoryTest {

    @TempDir
    Path pasta;

    private Path arquivo;
    private TarefaRepository repo;

    @BeforeEach
    void preparar() {
        arquivo = pasta.resolve("tarefas.txt");
        repo = new TarefaRepository(arquivo.toString());
    }

    @Test
    @DisplayName("CT-11 (RF-01, RNF-02): salvar grava no formato id|concluida|descricao")
    void salvaNoFormatoDoArquivo() throws Exception {
        repo.salvar(new Tarefa(1, "Estudar UML", false));
        assertEquals(List.of("1|false|Estudar UML"), Files.readAllLines(arquivo));

        Tarefa lida = repo.buscarTodas().get(0);
        assertEquals(1, lida.getId());
        assertEquals("Estudar UML", lida.getDescricao());
        assertFalse(lida.isConcluida());
    }

    @Test
    @DisplayName("CT-12 (RN-03): buscarPorId de id inexistente retorna null")
    void buscarPorIdInexistente() {
        repo.salvar(new Tarefa(1, "A", false));
        assertNull(repo.buscarPorId(2));
        assertNotNull(repo.buscarPorId(1));
    }

    @Test
    @DisplayName("CT-13 (RF-03): atualizar altera só a tarefa informada")
    void atualizaSomenteATarefa() {
        repo.salvar(new Tarefa(1, "A", false));
        repo.salvar(new Tarefa(2, "B", false));
        Tarefa b = repo.buscarPorId(2);
        b.marcarConcluida();
        repo.atualizar(b);

        assertFalse(repo.buscarPorId(1).isConcluida());
        assertTrue(repo.buscarPorId(2).isConcluida());
        assertEquals(2, repo.buscarTodas().size());
    }

    @Test
    @DisplayName("CT-14 (R-01): linhas em branco no arquivo são ignoradas")
    void ignoraLinhasEmBranco() throws Exception {
        Files.write(arquivo, List.of("1|false|A", "", "   ", "2|true|B"));
        assertEquals(2, repo.buscarTodas().size());
    }
}
