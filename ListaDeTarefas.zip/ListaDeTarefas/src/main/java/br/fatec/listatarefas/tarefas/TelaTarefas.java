package br.fatec.listatarefas.tarefas;

import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * View de console do "aplicativo" e, no padrão GoF Command, o "Invoker":
 * guarda os comandos por tecla e executa o escolhido, sem saber o que cada um faz.
 */
public class TelaTarefas {

    private final Scanner entrada;
    private final PrintStream saida;
    private final Map<String, ComandoMenu> comandos = new LinkedHashMap<>();
    private final ComandoMenu listar;

    /** Tela real: lê o teclado na codificação do sistema (ex.: Windows-1252 no NetBeans/cmd). */
    public TelaTarefas(TarefaController controller) {
        this(controller, System.in, System.out, charsetDoTeclado());
    }

    /** Usado nos testes: entrada em UTF-8. */
    public TelaTarefas(TarefaController controller, InputStream in, PrintStream out) {
        this(controller, in, out, StandardCharsets.UTF_8);
    }

    public TelaTarefas(TarefaController controller, InputStream in, PrintStream out, Charset charsetEntrada) {
        this.entrada = new Scanner(in, charsetEntrada);
        this.saida = out;
        this.listar = new ListarTarefasComando(controller, saida);
        registrar("1", new NovaTarefaComando(controller, entrada, saida, listar));
        registrar("2", listar);
        registrar("3", new ConcluirTarefaComando(controller, entrada, saida, listar));
    }

    /**
     * Codificação em que o terminal envia o que o usuário digita.
     * A partir do JDK 18 o padrão do Java é UTF-8, mas o console do Windows e o
     * terminal do NetBeans enviam o texto na codificação do sistema (Windows-1252),
     * o que transformava "ação" em "a??o".
     */
    static Charset charsetDoTeclado() {
        if (System.console() != null) {
            return System.console().charset();
        }
        String nativo = System.getProperty("native.encoding");
        return nativo != null ? Charset.forName(nativo) : Charset.defaultCharset();
    }

    /** Novas opções entram no menu sem alterar o laço de execução. */
    public final void registrar(String tecla, ComandoMenu comando) {
        comandos.put(tecla, comando);
    }

    public void iniciar() {
        saida.println("=== Lista de Tarefas ===");
        listar.executar();                       // Fluxo B: ao abrir o app
        while (true) {
            saida.println();
            comandos.forEach((tecla, c) -> saida.println(tecla + " - " + c.descricao()));
            saida.println("0 - Sair");
            saida.print("Escolha: ");
            if (!entrada.hasNextLine()) {
                break;
            }
            String opcao = entrada.nextLine().trim();
            if (opcao.equals("0")) {
                break;
            }
            ComandoMenu comando = comandos.get(opcao);
            if (comando == null) {
                saida.println("Opção inválida.");
            } else {
                comando.executar();
            }
        }
        saida.println("Até logo!");
    }
}
