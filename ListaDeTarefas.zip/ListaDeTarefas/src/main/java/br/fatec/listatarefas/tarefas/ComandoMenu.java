package br.fatec.listatarefas.tarefas;

/**
 * Padrão GoF Command — papel "Command".
 * Cada opção do menu da tela é um objeto que sabe se executar.
 */
public interface ComandoMenu {

    /** Texto exibido no menu (ex.: "Nova tarefa"). */
    String descricao();

    /** Executa a ação da opção. */
    void executar();
}
