package br.fatec.listatarefas.tarefas;

/** ConcreteCommand: exclui uma tarefa (RF-04 / Fluxo D). */
public class ExcluirTarefaComando implements ComandoMenu {

    private final TarefaController controller;   // Receiver
    private final InteracaoUsuario tela;
    private final ComandoMenu listar;

    public ExcluirTarefaComando(TarefaController controller, InteracaoUsuario tela, ComandoMenu listar) {
        this.controller = controller;
        this.tela = tela;
        this.listar = listar;
    }

    @Override
    public String descricao() {
        return "Excluir tarefa";
    }

    @Override
    public void executar() {
        String numero = tela.pedir("Número da tarefa").trim();
        if (numero.isEmpty()) {
            tela.mostrarErro("selecione ou informe a tarefa.");
            return;
        }
        try {
            controller.excluirTarefa(Integer.parseInt(numero));
            listar.executar();
        } catch (NumberFormatException e) {
            tela.mostrarErro("informe um número válido.");
        } catch (IllegalArgumentException e) {
            tela.mostrarErro(e.getMessage());
        }
    }
}
