package br.fatec.listatarefas.tarefas;

import java.util.List;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

/**
 * Controller da tela gráfica (TelaTarefas.fxml).
 * No padrão GoF Command é o "Invoker" dos botões: cada botão executa um comando.
 * Também implementa InteracaoUsuario, para os comandos lerem o campo e a seleção
 * e mostrarem a lista e os erros na tela.
 */
public class TelaTarefasFxController implements InteracaoUsuario {

    @FXML private TextField campoDescricao;
    @FXML private ListView<Tarefa> listaTarefas;
    @FXML private Label mensagem;
    @FXML private Label resumo;
    @FXML private Button botaoConcluir;
    @FXML private Button botaoExcluir;

    private ComandoMenu comandoAdicionar;
    private ComandoMenu comandoConcluir;
    private ComandoMenu comandoExcluir;

    /** Chamado pelo FXMLLoader: aparência da lista e botões que dependem de seleção. */
    @FXML
    void initialize() {
        listaTarefas.setCellFactory(lista -> new CelulaTarefa());
        botaoConcluir.disableProperty().bind(listaTarefas.getSelectionModel().selectedItemProperty().isNull());
        botaoExcluir.disableProperty().bind(listaTarefas.getSelectionModel().selectedItemProperty().isNull());
    }

    /** Chamado depois de carregar o FXML: liga a tela ao TarefaController e mostra a lista. */
    public void inicializar(TarefaController controller) {
        ComandoMenu listar = new ListarTarefasComando(controller, this);
        comandoAdicionar = new NovaTarefaComando(controller, this, listar);
        comandoConcluir = new ConcluirTarefaComando(controller, this, listar);
        comandoExcluir = new ExcluirTarefaComando(controller, this, listar);
        listar.executar();                       // Fluxo B: ao abrir o app
    }

    /** Botão "Adicionar" ou Enter no campo (Fluxo A). */
    @FXML
    void adicionar() {
        comandoAdicionar.executar();
    }

    /** Botão "Concluir" (Fluxo C). */
    @FXML
    void concluir() {
        comandoConcluir.executar();
    }

    /** Botão "Excluir" (Fluxo D). */
    @FXML
    void excluir() {
        comandoExcluir.executar();
    }

    @Override
    public String pedir(String rotulo) {
        if (rotulo.startsWith("Número")) {
            Tarefa selecionada = listaTarefas.getSelectionModel().getSelectedItem();
            return selecionada == null ? "" : String.valueOf(selecionada.getId());
        }
        return campoDescricao.getText();
    }

    @Override
    public void mostrarErro(String texto) {
        mensagem.setText("Erro: " + texto);
        mensagem.setManaged(true);
        mensagem.setVisible(true);
    }

    @Override
    public void mostrarTarefas(List<Tarefa> tarefas) {
        listaTarefas.getItems().setAll(tarefas);
        campoDescricao.clear();
        mensagem.setText("");
        mensagem.setManaged(false);
        mensagem.setVisible(false);
        resumo.setText(textoResumo(tarefas));
    }

    /** Ex.: "3 tarefas · 1 concluída · 2 pendentes". */
    static String textoResumo(List<Tarefa> tarefas) {
        if (tarefas.isEmpty()) {
            return "Nenhuma tarefa";
        }
        long concluidas = tarefas.stream().filter(Tarefa::isConcluida).count();
        long pendentes = tarefas.size() - concluidas;
        return tarefas.size() + (tarefas.size() == 1 ? " tarefa" : " tarefas")
                + " · " + concluidas + (concluidas == 1 ? " concluída" : " concluídas")
                + " · " + pendentes + (pendentes == 1 ? " pendente" : " pendentes");
    }

    /** Como cada tarefa aparece na lista: número, descrição e selo de status. */
    private static class CelulaTarefa extends ListCell<Tarefa> {

        CelulaTarefa() {
            setPrefWidth(0);                     // a célula acompanha a largura da lista (sem rolagem lateral)
        }

        @Override
        protected void updateItem(Tarefa tarefa, boolean vazia) {
            super.updateItem(tarefa, vazia);
            setText(null);
            if (vazia || tarefa == null) {
                setGraphic(null);
                return;
            }
            Label numero = new Label("#" + tarefa.getId());
            numero.getStyleClass().add("item-numero");

            Label texto = new Label(tarefa.getDescricao());
            texto.getStyleClass().add("item-texto");
            texto.setWrapText(true);
            texto.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(texto, Priority.ALWAYS);
            if (tarefa.isConcluida()) {
                texto.getStyleClass().add("concluida");
            }

            Label selo = new Label(tarefa.isConcluida() ? "Concluída" : "Pendente");
            selo.getStyleClass().addAll("selo", tarefa.isConcluida() ? "selo-concluida" : "selo-pendente");
            selo.setMinWidth(Region.USE_PREF_SIZE);  // o selo nunca é cortado
            numero.setMinWidth(Region.USE_PREF_SIZE);

            HBox linha = new HBox(numero, texto, selo);
            linha.getStyleClass().add("item");
            setGraphic(linha);
        }
    }
}
