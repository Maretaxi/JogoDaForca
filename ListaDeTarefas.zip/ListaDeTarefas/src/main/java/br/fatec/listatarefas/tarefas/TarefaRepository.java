package br.fatec.listatarefas.tarefas;

import java.util.ArrayList;
import java.util.List;

/**
 * Repository: converte entre linhas do arquivo e objetos Tarefa.
 * Formato de cada linha:  id|concluida|descricao
 */
public class TarefaRepository {

    private static final String SEPARADOR = "|";

    private final String arquivo;
    private final ListaDeTarefas lista;

    public TarefaRepository() {
        this(ListaDeTarefas.ARQUIVO_PADRAO);
    }

    public TarefaRepository(String arquivo) {
        this.arquivo = arquivo;
        this.lista = new ListaDeTarefas(arquivo);
    }

    /** Acrescenta uma nova linha no arquivo. */
    public void salvar(Tarefa tarefa) {
        List<String> linhas = lista.lerLinhas();
        linhas.add(paraLinha(tarefa));
        lista.gravarLinhas(linhas);
    }

    public List<Tarefa> buscarTodas() {
        List<Tarefa> tarefas = new ArrayList<>();
        for (String linha : lista.lerLinhas()) {
            if (!linha.isBlank()) {
                tarefas.add(deLinha(linha));
            }
        }
        return tarefas;
    }

    /** @return a tarefa, ou null se o id não existir. */
    public Tarefa buscarPorId(int id) {
        for (Tarefa t : buscarTodas()) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    /** Reescreve o arquivo inteiro com a tarefa atualizada. */
    public void atualizar(Tarefa tarefa) {
        List<String> novas = new ArrayList<>();
        for (Tarefa t : buscarTodas()) {
            novas.add(paraLinha(t.getId() == tarefa.getId() ? tarefa : t));
        }
        lista.gravarLinhas(novas);
    }

    /** Reescreve o arquivo sem a tarefa do id informado. */
    public void remover(int id) {
        List<String> novas = new ArrayList<>();
        for (Tarefa t : buscarTodas()) {
            if (t.getId() != id) {
                novas.add(paraLinha(t));
            }
        }
        lista.gravarLinhas(novas);
    }

    public String getArquivo() {
        return arquivo;
    }

    private String paraLinha(Tarefa t) {
        return t.getId() + SEPARADOR + t.isConcluida() + SEPARADOR + t.getDescricao();
    }

    private Tarefa deLinha(String linha) {
        String[] partes = linha.split("\\|", 3);
        return new Tarefa(Integer.parseInt(partes[0]), partes[2], Boolean.parseBoolean(partes[1]));
    }
}
