package br.fatec.listatarefas;

import br.fatec.listatarefas.tarefas.TelaTarefasFxController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/** Abre a janela da Lista de Tarefas a partir de TelaTarefas.fxml. */
public class AppTarefas extends Application {

    @Override
    public void start(Stage janela) throws Exception {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/br/fatec/listatarefas/tarefas/TelaTarefas.fxml"));
        Parent raiz = loader.load();
        TelaTarefasFxController tela = loader.getController();
        tela.inicializar(Main.criarController());

        janela.setTitle("Lista de Tarefas");
        janela.setScene(new Scene(raiz));
        janela.setMinWidth(380);
        janela.setMinHeight(460);
        janela.show();
    }
}
