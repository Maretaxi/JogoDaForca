package br.fatec.listatarefas.tarefas;

/**
 * Entidade (Model): uma tarefa da lista.
 * Atributos e método conforme o diagrama de classes.
 */
public class Tarefa {

    private int id;
    private String descricao;
    private boolean concluida;

    public Tarefa(int id, String descricao, boolean concluida) {
        this.id = id;
        this.descricao = descricao;
        this.concluida = concluida;
    }

    public void marcarConcluida() {
        this.concluida = true;
    }

    public int getId() {
        return id;
    }

    public String getDescricao() {
        return descricao;
    }

    public boolean isConcluida() {
        return concluida;
    }

    @Override
    public String toString() {
        return id + " - [" + (concluida ? "x" : " ") + "] " + descricao;
    }
}
