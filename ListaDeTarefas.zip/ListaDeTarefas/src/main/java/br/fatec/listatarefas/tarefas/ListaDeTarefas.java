package br.fatec.listatarefas.tarefas;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Persistência: representa o arquivo "Lista de tarefas.txt",
 * onde as tarefas ficam guardadas (uma por linha).
 * Só sabe ler e gravar linhas; quem converte linha <-> Tarefa é o repositório.
 */
public class ListaDeTarefas {

    public static final String ARQUIVO_PADRAO = "Lista de tarefas.txt";

    private final String arquivo;

    public ListaDeTarefas() {
        this(ARQUIVO_PADRAO);
    }

    public ListaDeTarefas(String arquivo) {
        this.arquivo = arquivo;
    }

    public List<String> lerLinhas() {
        Path caminho = Paths.get(arquivo);
        if (!Files.exists(caminho)) {
            return new ArrayList<>();
        }
        try {
            return new ArrayList<>(Files.readAllLines(caminho, StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new UncheckedIOException("Não foi possível ler o arquivo " + arquivo, e);
        }
    }

    public void gravarLinhas(List<String> linhas) {
        try {
            Files.write(Paths.get(arquivo), linhas, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Não foi possível gravar o arquivo " + arquivo, e);
        }
    }
}
