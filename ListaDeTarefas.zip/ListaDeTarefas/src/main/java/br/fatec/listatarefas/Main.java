package br.fatec.listatarefas;

import br.fatec.listatarefas.tarefas.TarefaController;
import br.fatec.listatarefas.tarefas.TarefaRepository;
import br.fatec.listatarefas.tarefas.TarefaService;
import br.fatec.listatarefas.tarefas.TelaTarefas;
import javafx.application.Application;

/**
 * Ponto de entrada. Abre a tela gráfica (TelaTarefas.fxml).
 * Com o argumento --console, abre a tela de console.
 * Esta classe não estende Application de propósito: assim o NetBeans (F6)
 * consegue rodar o JavaFX pelo classpath, sem configurar módulos.
 */
public class Main {

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("--console")) {
            new TelaTarefas(criarController()).iniciar();
        } else {
            Application.launch(AppTarefas.class, args);
        }
    }

    /** Monta Repository -> Service -> Controller. */
    static TarefaController criarController() {
        TarefaRepository repositorio = new TarefaRepository();
        TarefaService service = new TarefaService(repositorio);
        return new TarefaController(service);
    }
}
