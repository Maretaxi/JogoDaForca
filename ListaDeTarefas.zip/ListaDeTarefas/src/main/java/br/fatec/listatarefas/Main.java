package br.fatec.listatarefas;

import br.fatec.listatarefas.tarefas.TarefaController;
import br.fatec.listatarefas.tarefas.TarefaRepository;
import br.fatec.listatarefas.tarefas.TarefaService;
import br.fatec.listatarefas.tarefas.TelaTarefas;

/** Ponto de entrada: monta Repository -> Service -> Controller -> Tela. */
public class Main {

    public static void main(String[] args) {
        TarefaRepository repositorio = new TarefaRepository();
        TarefaService service = new TarefaService(repositorio);
        TarefaController controller = new TarefaController(service);
        new TelaTarefas(controller).iniciar();
    }
}
