package br.fatec.listatarefas.tarefas;

import java.util.List;

/**
 * Controller: recebe as ações da tela e repassa ao Service.
 * Não tem regra de negócio.
 */
public class TarefaController {

    private final TarefaService service;

    public TarefaController() {
        this(new TarefaService());
    }

    public TarefaController(TarefaService service) {
        this.service = service;
    }

    public void adicionarTarefa(String descricao) {
        service.criar(descricao);
    }

    public List<Tarefa> carregarTarefas() {
        return service.listarTodas();
    }

    public void concluirTarefa(int id) {
        service.concluir(id);
    }
}
