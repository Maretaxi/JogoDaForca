package br.fatec.listatarefas.tarefas;

import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;

/** Interação pelo console: pede com Scanner e mostra com PrintStream. */
public class InteracaoConsole implements InteracaoUsuario {

    private final Scanner entrada;
    private final PrintStream saida;

    public InteracaoConsole(Scanner entrada, PrintStream saida) {
        this.entrada = entrada;
        this.saida = saida;
    }

    @Override
    public String pedir(String rotulo) {
        saida.print(rotulo + ": ");
        return entrada.hasNextLine() ? entrada.nextLine() : "";
    }

    @Override
    public void mostrarErro(String mensagem) {
        saida.println("Erro: " + mensagem);
    }

    @Override
    public void mostrarTarefas(List<Tarefa> tarefas) {
        saida.println();
        if (tarefas.isEmpty()) {
            saida.println("(nenhuma tarefa cadastrada)");
            return;
        }
        for (Tarefa t : tarefas) {
            saida.println(t);
        }
    }
}
