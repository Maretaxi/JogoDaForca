package br.fatec.listatarefas.tarefas;

import java.util.List;

/**
 * Service: regras de negócio.
 *  RN-01: a descrição não pode ser vazia.
 *  RN-02: a descrição tem no máximo 100 caracteres e não pode conter '|' nem quebra de linha.
 *  RN-03: só é possível concluir uma tarefa que exista.
 */
public class TarefaService {

    public static final int TAMANHO_MAXIMO = 100;

    private final TarefaRepository repositorio;

    public TarefaService() {
        this(new TarefaRepository());
    }

    public TarefaService(TarefaRepository repositorio) {
        this.repositorio = repositorio;
    }

    public Tarefa criar(String descricao) {
        if (descricao == null || descricao.isBlank()) {
            throw new IllegalArgumentException("A descrição da tarefa não pode ser vazia.");
        }
        descricao = descricao.trim();
        if (descricao.length() > TAMANHO_MAXIMO) {
            throw new IllegalArgumentException("A descrição deve ter no máximo " + TAMANHO_MAXIMO + " caracteres.");
        }
        if (descricao.contains("|") || descricao.contains("\n") || descricao.contains("\r")) {
            throw new IllegalArgumentException("A descrição não pode conter '|' nem quebra de linha.");
        }
        Tarefa tarefa = new Tarefa(proximoId(), descricao, false);
        repositorio.salvar(tarefa);
        return tarefa;
    }

    public List<Tarefa> listarTodas() {
        return repositorio.buscarTodas();
    }

    public void concluir(int id) {
        Tarefa tarefa = repositorio.buscarPorId(id);
        if (tarefa == null) {
            throw new IllegalArgumentException("Tarefa " + id + " não encontrada.");
        }
        tarefa.marcarConcluida();
        repositorio.atualizar(tarefa);
    }

    private int proximoId() {
        int maior = 0;
        for (Tarefa t : repositorio.buscarTodas()) {
            maior = Math.max(maior, t.getId());
        }
        return maior + 1;
    }
}
