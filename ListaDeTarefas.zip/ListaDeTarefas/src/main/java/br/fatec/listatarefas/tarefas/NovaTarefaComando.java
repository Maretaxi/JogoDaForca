package br.fatec.listatarefas.tarefas;

/** ConcreteCommand: cadastra uma tarefa (RF-01 / Fluxo A). */
public class NovaTarefaComando implements ComandoMenu {

    private final TarefaController controller;   // Receiver
    private final InteracaoUsuario tela;
    private final ComandoMenu listar;

    public NovaTarefaComando(TarefaController controller, InteracaoUsuario tela, ComandoMenu listar) {
        this.controller = controller;
        this.tela = tela;
        this.listar = listar;
    }

    @Override
    public String descricao() {
        return "Nova tarefa";
    }

    @Override
    public void executar() {
        try {
            controller.adicionarTarefa(tela.pedir("Descrição"));
            listar.executar();
        } catch (IllegalArgumentException e) {
            tela.mostrarErro(e.getMessage());
        }
    }
}
