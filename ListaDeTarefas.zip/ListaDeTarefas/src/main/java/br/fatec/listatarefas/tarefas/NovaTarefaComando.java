package br.fatec.listatarefas.tarefas;

import java.io.PrintStream;
import java.util.Scanner;

/** ConcreteCommand: cadastra uma tarefa (RF-01 / Fluxo A). */
public class NovaTarefaComando implements ComandoMenu {

    private final TarefaController controller;   // Receiver
    private final Scanner entrada;
    private final PrintStream saida;
    private final ComandoMenu listar;

    public NovaTarefaComando(TarefaController controller, Scanner entrada,
                             PrintStream saida, ComandoMenu listar) {
        this.controller = controller;
        this.entrada = entrada;
        this.saida = saida;
        this.listar = listar;
    }

    @Override
    public String descricao() {
        return "Nova tarefa";
    }

    @Override
    public void executar() {
        saida.print("Descrição: ");
        try {
            controller.adicionarTarefa(entrada.nextLine());
            listar.executar();
        } catch (IllegalArgumentException e) {
            saida.println("Erro: " + e.getMessage());
        }
    }
}
