package br.fatec.listatarefas.tarefas;

import java.util.List;

/**
 * O que os comandos precisam da tela, sem saber se ela é gráfica (JavaFX) ou de console.
 * Assim os mesmos comandos (padrão Command) servem para as duas telas.
 */
public interface InteracaoUsuario {

    /** Pede um valor ao usuário (ex.: a descrição ou o número da tarefa). */
    String pedir(String rotulo);

    /** Mostra uma mensagem de erro. */
    void mostrarErro(String mensagem);

    /** Mostra a lista de tarefas atualizada. */
    void mostrarTarefas(List<Tarefa> tarefas);
}
