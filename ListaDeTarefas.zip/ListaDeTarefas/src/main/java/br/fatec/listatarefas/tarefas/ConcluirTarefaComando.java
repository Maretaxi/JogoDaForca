package br.fatec.listatarefas.tarefas;

/** ConcreteCommand: marca uma tarefa como concluída (RF-03 / Fluxo C). */
public class ConcluirTarefaComando implements ComandoMenu {

    private final TarefaController controller;   // Receiver
    private final InteracaoUsuario tela;
    private final ComandoMenu listar;

    public ConcluirTarefaComando(TarefaController controller, InteracaoUsuario tela, ComandoMenu listar) {
        this.controller = controller;
        this.tela = tela;
        this.listar = listar;
    }

    @Override
    public String descricao() {
        return "Marcar tarefa como concluída";
    }

    @Override
    public void executar() {
        String numero = tela.pedir("Número da tarefa").trim();
        if (numero.isEmpty()) {
            tela.mostrarErro("selecione ou informe a tarefa.");
            return;
        }
        try {
            controller.concluirTarefa(Integer.parseInt(numero));
            listar.executar();
        } catch (NumberFormatException e) {
            tela.mostrarErro("informe um número válido.");
        } catch (IllegalArgumentException e) {
            tela.mostrarErro(e.getMessage());
        }
    }
}
