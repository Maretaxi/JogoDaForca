package br.fatec.listatarefas.tarefas;

import java.io.PrintStream;
import java.util.Scanner;

/** ConcreteCommand: marca uma tarefa como concluída (RF-03 / Fluxo C). */
public class ConcluirTarefaComando implements ComandoMenu {

    private final TarefaController controller;   // Receiver
    private final Scanner entrada;
    private final PrintStream saida;
    private final ComandoMenu listar;

    public ConcluirTarefaComando(TarefaController controller, Scanner entrada,
                                 PrintStream saida, ComandoMenu listar) {
        this.controller = controller;
        this.entrada = entrada;
        this.saida = saida;
        this.listar = listar;
    }

    @Override
    public String descricao() {
        return "Marcar tarefa como concluída";
    }

    @Override
    public void executar() {
        saida.print("Número da tarefa: ");
        try {
            controller.concluirTarefa(Integer.parseInt(entrada.nextLine().trim()));
            listar.executar();
        } catch (NumberFormatException e) {
            saida.println("Erro: informe um número válido.");
        } catch (IllegalArgumentException e) {
            saida.println("Erro: " + e.getMessage());
        }
    }
}
