package br.fatec.listatarefas.tarefas;

import java.io.PrintStream;
import java.util.List;

/** ConcreteCommand: exibe a lista de tarefas (RF-02 / Fluxo B). */
public class ListarTarefasComando implements ComandoMenu {

    private final TarefaController controller;   // Receiver
    private final PrintStream saida;

    public ListarTarefasComando(TarefaController controller, PrintStream saida) {
        this.controller = controller;
        this.saida = saida;
    }

    @Override
    public String descricao() {
        return "Listar tarefas";
    }

    @Override
    public void executar() {
        List<Tarefa> tarefas = controller.carregarTarefas();
        saida.println();
        if (tarefas.isEmpty()) {
            saida.println("(nenhuma tarefa cadastrada)");
            return;
        }
        for (Tarefa t : tarefas) {
            saida.println(t);
        }
    }
}
