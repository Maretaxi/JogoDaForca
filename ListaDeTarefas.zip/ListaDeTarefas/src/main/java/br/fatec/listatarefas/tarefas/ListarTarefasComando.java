package br.fatec.listatarefas.tarefas;

/** ConcreteCommand: exibe a lista de tarefas (RF-02 / Fluxo B). */
public class ListarTarefasComando implements ComandoMenu {

    private final TarefaController controller;   // Receiver
    private final InteracaoUsuario tela;

    public ListarTarefasComando(TarefaController controller, InteracaoUsuario tela) {
        this.controller = controller;
        this.tela = tela;
    }

    @Override
    public String descricao() {
        return "Listar tarefas";
    }

    @Override
    public void executar() {
        tela.mostrarTarefas(controller.carregarTarefas());
    }
}
