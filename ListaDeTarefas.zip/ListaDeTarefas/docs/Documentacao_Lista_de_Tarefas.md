# Documentação do Software — Lista de Tarefas

| Campo | Valor |
|---|---|
| **Versão do documento** | 2.2 |
| **Data** | 27/11/2026 |
| **Autor(es)** | André Vitor Caldas Macedo, Daniel França Ribeiro, Lucas Marques Lucena, Paulo Henrique de Sousa Azevedo, Vinicius Souza Targino |
| **Status** | Em revisão |
| **Aprovado por** | — |

## Histórico de Revisões

| Versão | Data | Autor | Descrição da alteração |
|---|---|---|---|
| 1.0 | 28/08/2026 | Grupo | Criação do documento |
| 2.0 | 27/11/2026 | Grupo | Adequação ao modelo V2: diagrama de casos de uso, padrão GoF Command, diagramas de classes e de sequência atualizados, testes JUnit em 5 classes com cobertura, matriz de rastreabilidade completa. Correção de defeito encontrado no CT-24: acentos digitados no Windows eram lidos como "?" (novo CT-25) |
| 2.1 | 27/11/2026 | Grupo | A tela gráfica JavaFX (`TelaTarefas.fxml`) passa a ser a tela principal, como combinado; o console vira alternativa (`--console`). Os comandos do padrão Command passam a ser usados pelas duas telas (interface `InteracaoUsuario`). Novos testes da tela gráfica (CT-26 a CT-31) e teste manual CT-32 |
| 2.2 | 27/11/2026 | Grupo | Nova funcionalidade: excluir tarefa (RF-04, UC-05, comando `ExcluirTarefaComando`, também no console como opção 4). Tela gráfica redesenhada com CSS (`tarefas.css`): cabeçalho com resumo, tarefas em cartões com selo Pendente/Concluída, botões coloridos que só ficam ativos com uma tarefa selecionada. Novos testes CT-33 a CT-41 |

---

## Sumário

1. [Visão Geral](#1-visão-geral)
2. [Escopo do Projeto](#2-escopo-do-projeto)
3. [Requisitos Funcionais](#3-requisitos-funcionais)
4. [Requisitos Não Funcionais](#4-requisitos-não-funcionais)
5. [Regras de Negócio](#5-regras-de-negócio)
6. [Projeto e Arquitetura do Software](#6-projeto-e-arquitetura-do-software)
7. [Plano e Casos de Teste](#7-plano-e-casos-de-teste)
8. [Matriz de Rastreabilidade](#8-matriz-de-rastreabilidade-requisitos-x-testes-x-código-fonte)
9. [Glossário](#9-glossário)
10. [Anexos e Referências](#10-anexos-e-referências)

---

## 1. Visão Geral

### 1.1 Propósito do documento
Documentar os requisitos, a arquitetura, o projeto, os testes e a rastreabilidade do aplicativo Lista de Tarefas. O documento se destina à equipe de desenvolvimento, a quem fizer os testes (QA) e à professora responsável pela avaliação.

### 1.2 Descrição resumida do sistema
A Lista de Tarefas é um aplicativo local, sem backend, desenvolvido em Java. Nele o usuário cadastra tarefas, consulta a lista, marca tarefas como concluídas e exclui tarefas. As tarefas ficam gravadas no arquivo de texto `Lista de tarefas.txt` no próprio dispositivo e continuam lá depois que o aplicativo é fechado. A tela principal é gráfica, em JavaFX (`TelaTarefas.fxml`). Também existe uma tela de console, aberta com o argumento `--console`.

### 1.3 Stakeholders

| Nome / Papel | Responsabilidade | Contato |
|---|---|---|
| Product Owner — Grupo | Definição e priorização dos requisitos | — |
| Arquiteto de Software — Grupo | Arquitetura em camadas, pacote por funcionalidade e padrão Command | — |
| Time de Desenvolvimento — André, Daniel, Lucas, Paulo Henrique, Vinicius | Implementação em Java | — |
| Time de QA — Grupo | Testes JUnit e testes manuais | — |
| Cliente / Patrocinador — Profa. Andrea Zotovici | Avaliação e aprovação do documento | — |
| Usuário final | Usa o aplicativo para organizar suas tarefas | — |

---

## 2. Escopo do Projeto

### 2.1 Objetivos do projeto
- Permitir que o usuário cadastre, liste, conclua e exclua tarefas de forma simples.
- Manter as tarefas salvas entre uma execução e outra, sem depender de internet ou de servidor.
- Aplicar na prática MVC, organização por funcionalidade, um padrão de projeto GoF e testes unitários com JUnit.

### 2.2 Dentro do escopo (In Scope)
- Adicionar tarefa com descrição (RF-01).
- Listar tarefas, ao abrir o aplicativo e sob demanda (RF-02).
- Marcar tarefa como concluída (RF-03).
- Excluir tarefa (RF-04).
- Persistência em arquivo de texto local.
- Validação das entradas do usuário (RN-01 a RN-03).
- Tela gráfica (JavaFX, principal) e tela de console (alternativa).

### 2.3 Fora do escopo (Out of Scope)
- Backend, contas de usuário, login e sincronização entre aparelhos.
- Editar ou reabrir tarefas; desfazer uma exclusão.
- Prazos, prioridades, categorias e lembretes.

### 2.4 Premissas
- O aplicativo roda em um único dispositivo e é usado por uma única pessoa.
- O dispositivo tem JDK 17 ou superior instalado.
- O usuário tem permissão de escrita na pasta em que o aplicativo é executado.

### 2.5 Restrições
- Implementação em Java 17+, com projeto Maven aberto no NetBeans.
- Tela gráfica em JavaFX 21 com FXML, como combinado para o projeto.
- Persistência apenas em arquivo de texto (`Lista de tarefas.txt`), sem banco de dados.
- Prazo: entrega da disciplina no segundo semestre de 2026.

### 2.6 Riscos identificados

| ID | Risco | Probabilidade | Impacto | Mitigação |
|---|---|---|---|---|
| R-01 | Arquivo apagado, ausente ou com linhas em branco | Média | Médio | Arquivo ausente é lido como lista vazia e linhas em branco são ignoradas (CT-14, CT-18) |
| R-02 | Arquivo grande deixa as operações lentas, porque o arquivo inteiro é relido a cada operação | Baixa | Baixo | Desempenho medido com 1.000 tarefas (CT-09); evoluir para banco local (SQLite) se necessário |
| R-03 | Descrição com o separador `\|` ou com quebra de linha corrompe o formato do arquivo | Média | Alto | Proibido pela RN-02 e validado no `TarefaService` (CT-06) |
| R-04 | Terminal envia o texto digitado numa codificação diferente da que o Java usa (ex.: Windows-1252 × UTF-8), estragando acentos | Alta | Médio | Ocorreu no CT-24 (console); corrigido lendo o teclado na codificação do sistema (CT-25). Na tela gráfica o problema não existe (CT-31) |
| R-05 | Testes da tela gráfica precisam de um monitor (display) | Baixa | Baixo | Em máquina sem tela, esses testes são pulados (não falham); no NetBeans eles rodam normalmente |

### 2.7 Entregáveis
- Projeto NetBeans/Maven com o código-fonte e os testes JUnit.
- Este documento, com os diagramas de casos de uso, arquitetura, classes e sequência.
- Pasta `docs/diagramas/`: containers (`Conteiners.drawio`, `Cliente.pdf`), casos de uso editável (`CasosDeUso.drawio`), classes (`classes_tarefas.pdf`) e sequência/comunicação (`DiagramaSequencia-Colaboracao.pdf`).
- Tela gráfica: `TelaTarefas.fxml` com o controller `TelaTarefasFxController` (captura em `docs/diagramas/tela_principal.png`).

---

## 3. Requisitos Funcionais

> Requisitos funcionais descrevem **o que** o sistema deve fazer.

### Convenção de ID
`RF-XX` (Requisito Funcional número XX)

### 3.1 Lista de Requisitos Funcionais

| ID | Descrição | Prioridade | Origem / Solicitante | Status |
|---|---|---|---|---|
| RF-01 | O sistema deve permitir adicionar uma tarefa informando uma descrição. | Alta | Enunciado do projeto (disciplina) | Implementado |
| RF-02 | O sistema deve listar as tarefas cadastradas ao abrir o aplicativo e sempre que o usuário pedir. | Alta | Enunciado do projeto (disciplina) | Implementado |
| RF-03 | O sistema deve permitir marcar uma tarefa como concluída. | Alta | Enunciado do projeto (disciplina) | Implementado |
| RF-04 | O sistema deve permitir excluir uma tarefa. | Média | Pedido do grupo | Implementado |

### 3.2 Detalhamento dos Requisitos

#### RF-01 — Adicionar tarefa
- **Descrição:** o usuário cadastra uma nova tarefa informando a descrição. A tarefa recebe um número (id) e começa como não concluída.
- **Ator(es):** Usuário
- **Pré-condições:** aplicativo aberto.
- **Fluxo principal (tela gráfica):**
  1. O usuário digita a descrição no campo "Nova tarefa".
  2. O usuário clica em **Adicionar** (ou tecla Enter).
  3. O sistema valida a descrição (RN-01, RN-02), gera o id (RN-04) e grava a tarefa no arquivo.
  4. O sistema atualiza a lista (inclui UC-02) e limpa o campo.
- **Fluxo equivalente no console (`--console`):** opção "1 - Nova tarefa" e digitar a descrição.
- **Fluxos alternativos / exceções:**
  - Descrição vazia → o sistema exibe "Erro: A descrição da tarefa não pode ser vazia." e não grava nada.
  - Descrição com mais de 100 caracteres, com `|` ou com quebra de linha → o sistema exibe a mensagem de erro correspondente e não grava nada.
- **Pós-condições:** a nova tarefa está no arquivo `Lista de tarefas.txt`, não concluída.
- **Critérios de aceite:**
  - [x] A tarefa nova aparece na lista com `[ ]` e o próximo id disponível.
  - [x] Descrição vazia ou inválida é rejeitada com mensagem clara e nada é gravado.
- **Requisitos relacionados:** RN-01, RN-02, RN-04, RNF-05, RNF-06

#### RF-02 — Listar tarefas
- **Descrição:** o sistema mostra todas as tarefas na ordem de criação, indicando quais estão concluídas.
- **Ator(es):** Usuário
- **Pré-condições:** nenhuma (o arquivo pode não existir).
- **Fluxo principal:**
  1. O usuário abre o aplicativo (no console, também pela opção "2 - Listar tarefas").
  2. O sistema lê o arquivo e converte cada linha em uma tarefa.
  3. O sistema exibe cada tarefa no formato `id - [x] descrição`.
- **Fluxos alternativos / exceções:**
  - Arquivo inexistente ou vazio → a lista da tela gráfica fica vazia; no console aparece "(nenhuma tarefa cadastrada)".
- **Pós-condições:** nenhuma alteração nos dados.
- **Critérios de aceite:**
  - [x] As tarefas aparecem na ordem de criação, com `[x]` para concluída e `[ ]` para pendente.
  - [x] Sem tarefas, a lista aparece vazia, sem erro.
- **Requisitos relacionados:** RNF-01, RNF-02

#### RF-03 — Concluir tarefa
- **Descrição:** o usuário marca uma tarefa existente como concluída.
- **Ator(es):** Usuário
- **Pré-condições:** existir ao menos uma tarefa cadastrada.
- **Fluxo principal (tela gráfica):**
  1. O usuário seleciona a tarefa na lista.
  2. O usuário clica em **Concluir** (o botão só fica ativo com uma tarefa selecionada).
  3. O sistema busca a tarefa, marca como concluída e reescreve o arquivo.
  4. O sistema atualiza a lista (inclui UC-02).
- **Fluxo equivalente no console (`--console`):** opção "3" e digitar o número da tarefa.
- **Fluxos alternativos / exceções:**
  - Nenhuma tarefa selecionada (ou número em branco no console) → "Erro: selecione ou informe a tarefa."
  - Texto que não é número (console) → "Erro: informe um número válido."
  - Número de tarefa inexistente (console) → "Erro: Tarefa N não encontrada." (RN-03)
- **Pós-condições:** a tarefa fica concluída no arquivo e continua assim depois de reabrir o aplicativo.
- **Critérios de aceite:**
  - [x] A tarefa aparece com `[x]` e continua concluída após reabrir o aplicativo.
  - [x] Sem seleção, ou com número inválido ou inexistente, aparece mensagem de erro e o arquivo não muda.
- **Requisitos relacionados:** RN-03, RNF-02, RNF-05

#### RF-04 — Excluir tarefa
- **Descrição:** o usuário remove uma tarefa da lista e do arquivo.
- **Ator(es):** Usuário
- **Pré-condições:** existir ao menos uma tarefa cadastrada.
- **Fluxo principal (tela gráfica):**
  1. O usuário seleciona a tarefa na lista.
  2. O usuário clica em **Excluir** (o botão só fica ativo com uma tarefa selecionada).
  3. O sistema confere se a tarefa existe (RN-03) e reescreve o arquivo sem ela.
  4. O sistema atualiza a lista e o resumo do cabeçalho (inclui UC-02).
- **Fluxo equivalente no console (`--console`):** opção "4 - Excluir tarefa" e digitar o número da tarefa.
- **Fluxos alternativos / exceções:**
  - Nenhuma tarefa selecionada (ou número em branco no console) → "Erro: selecione ou informe a tarefa."
  - Texto que não é número (console) → "Erro: informe um número válido."
  - Número de tarefa inexistente (console) → "Erro: Tarefa N não encontrada." (RN-03)
- **Pós-condições:** a tarefa não aparece mais na lista nem no arquivo; as outras continuam na mesma ordem.
- **Critérios de aceite:**
  - [x] Só a tarefa escolhida é removida.
  - [x] Sem seleção, ou com número inexistente, aparece mensagem de erro e o arquivo não muda.
- **Requisitos relacionados:** RN-03, RNF-02, RNF-05

---

## 4. Requisitos Não Funcionais

> Requisitos não funcionais descrevem **como** o sistema deve se comportar. As categorias seguem o modelo de qualidade da **ISO/IEC 25010**, complementado pela análise de **conformidade legal (LGPD)**.

### Convenção de ID
`RNF-XX` (Requisito Não Funcional número XX)

### 4.1 Categorias segundo ISO/IEC 25010

| Característica ISO 25010 | Subcaracterísticas | Descrição |
|---|---|---|
| **Adequação Funcional** | Completude, Corretude, Pertinência funcional | O quanto o sistema atende às funções especificadas e às necessidades reais. |
| **Eficiência de Desempenho** | Comportamento temporal, Utilização de recursos, Capacidade | Desempenho relativo à quantidade de recursos usados (tempo de resposta, throughput, uso de CPU/memória). |
| **Compatibilidade** | Coexistência, Interoperabilidade | Capacidade de coexistir com outros sistemas e trocar informações com eles. |
| **Usabilidade** | Reconhecibilidade, Aprendizagem, Operabilidade, Proteção contra erros, Estética, Acessibilidade | Facilidade de uso e aprendizado pelo usuário. |
| **Confiabilidade** | Maturidade, Disponibilidade, Tolerância a falhas, Recuperabilidade | Capacidade de manter um nível de desempenho sob condições especificadas. |
| **Segurança** | Confidencialidade, Integridade, Não repúdio, Responsabilização (accountability), Autenticidade | Proteção de informações e dados contra acesso não autorizado. |
| **Manutenibilidade** | Modularidade, Reusabilidade, Analisabilidade, Modificabilidade, Testabilidade | Facilidade de modificar e evoluir o software. |
| **Portabilidade** | Adaptabilidade, Instalabilidade, Substituibilidade | Facilidade de transferir o software entre ambientes. |

### 4.2 Lista de Requisitos Não Funcionais

| ID | Característica ISO 25010 | Subcaracterística | Descrição | Critério de aceite / Métrica | Prioridade |
|---|---|---|---|---|---|
| RNF-01 | Eficiência de Desempenho | Comportamento temporal | Listar, adicionar e concluir tarefas deve ser imediato para uso pessoal. | Listar + adicionar + concluir com 1.000 tarefas em ≤ 1 s (CT-09) | Média |
| RNF-02 | Confiabilidade | Recuperabilidade | As tarefas devem permanecer após fechar e reabrir o aplicativo. | Dados relidos do arquivo na abertura, com status preservado (CT-10) | Alta |
| RNF-03 | Manutenibilidade | Modularidade / Testabilidade | Código em camadas (View, Controller, Service, Repository, Entity), organizado por funcionalidade e coberto por testes. | Testes em ≥ 3 classes; cobertura de linhas ≥ 80% (medido: 86,1%) | Alta |
| RNF-04 | Portabilidade | Adaptabilidade | O aplicativo deve rodar em qualquer sistema com JDK 17+, preservando acentos na digitação (tela gráfica e console) e gravando o arquivo sempre em UTF-8. | Acentos preservados no arquivo (CT-19), no console (CT-25) e na tela gráfica (CT-31); execução no Windows (CT-24, CT-32) | Média |
| RNF-05 | Usabilidade | Proteção contra erros | Entradas inválidas geram mensagem clara, sem encerrar o aplicativo. | Mensagens exibidas e o aplicativo continua (CT-21, CT-22, CT-28, CT-30, CT-38); Concluir e Excluir desabilitados sem seleção (CT-40) | Média |
| RNF-06 | Segurança | Integridade | A descrição digitada não pode corromper o formato do arquivo. | Descrições com `\|` ou quebra de linha rejeitadas (CT-06) | Alta |
| RNF-07 | Compatibilidade | Interoperabilidade | O arquivo de dados deve ser texto simples, legível e editável em qualquer editor. | Formato `id\|concluida\|descricao`, uma tarefa por linha (CT-11) | Baixa |
| RNF-08 | Adequação Funcional | Completude | Todas as funções do escopo (RF-01 a RF-04) devem estar implementadas e testadas. | 100% dos RFs com teste aprovado (matriz, Cap. 8) | Alta |

### 4.3 Conformidade com a LGPD (Lei nº 13.709/2018)

O aplicativo é local e de usuário único. Ele não coleta dados de terceiros, não tem cadastro nem login e não transmite nada pela rede. O único dado pessoal possível é algo que o próprio usuário decida escrever na descrição de uma tarefa. Esse dado fica somente no dispositivo dele, para uso particular. Nessa situação, a LGPD não se aplica: o **Art. 4º, I** exclui o tratamento realizado por pessoa natural para fins exclusivamente particulares e não econômicos. Mesmo assim, o projeto adota por decisão de design os princípios abaixo.

| ID | Princípio / Exigência LGPD | Descrição | Critério de aceite | Prioridade |
|---|---|---|---|---|
| RNF-L03 | Minimização de dados | O sistema guarda apenas id, status e descrição da tarefa; não pede nome, e-mail nem outro dado do usuário. | Formato do arquivo contém só os 3 campos (CT-11) | Média |
| RNF-L09 | Privacy by Design / by Default | Os dados ficam apenas no dispositivo; não há envio pela rede nem compartilhamento. | Ausência de qualquer integração externa (seção 6.12) | Média |
| RNF-L01, L02, L04 a L08, L10 | Finalidade, consentimento, direitos do titular, segurança, retenção, registro, incidentes, transferência internacional | Não se aplicam: não há tratamento de dados de terceiros por um controlador (Art. 4º, I). O próprio usuário pode ler, editar ou apagar o arquivo a qualquer momento. | — | — |

**Papéis relevantes (LGPD):** como o uso é exclusivamente particular, não há controlador, operador nem encarregado (DPO) neste sistema. Se o aplicativo passar a ter backend ou contas de usuário, os requisitos RNF-L01 a RNF-L10 do modelo precisarão ser reavaliados.

### 4.4 Mapeamento RNF × ISO 25010 × LGPD

| ID | Categoria | Referência normativa | Requisito(s) funcional(is) relacionado(s) |
|---|---|---|---|
| RNF-01 | Eficiência de Desempenho | ISO/IEC 25010 | RF-01, RF-02, RF-03 |
| RNF-02 | Confiabilidade | ISO/IEC 25010 | RF-01, RF-03, RF-04 |
| RNF-05 | Usabilidade | ISO/IEC 25010 | RF-01, RF-03, RF-04 |
| RNF-06 | Segurança (Integridade) | ISO/IEC 25010 | RF-01 |
| RNF-L03 | Adequação Funcional / Segurança | LGPD Art. 6º, III (necessidade) | RF-01 |
| RNF-L09 | Segurança | LGPD Art. 46, §2º (desde a concepção) | RF-01 a RF-04 |

---

## 5. Regras de Negócio

> Regras de negócio são políticas, restrições ou lógicas que devem ser respeitadas em todo o sistema.

### Convenção de ID
`RN-XX` (Regra de Negócio número XX)

### 5.1 Lista de Regras de Negócio

| ID | Descrição | Origem | Requisitos relacionados |
|---|---|---|---|
| RN-01 | A descrição da tarefa não pode ser vazia nem conter só espaços. | Definição do grupo | RF-01 |
| RN-02 | A descrição tem no máximo 100 caracteres e não pode conter `\|` nem quebra de linha, porque esses caracteres são os separadores do arquivo. | Definição do grupo (formato do arquivo) | RF-01, RNF-06 |
| RN-03 | Só é possível concluir ou excluir uma tarefa que exista. | Definição do grupo | RF-03, RF-04 |
| RN-04 | O id da nova tarefa é o maior id existente + 1, e toda tarefa nasce não concluída. | Definição do grupo | RF-01 |

---

## 6. Projeto e Arquitetura do Software

### 6.1 Diagrama de casos de uso

O ator único é o **Usuário**. Depois de adicionar, concluir ou excluir uma tarefa, o sistema sempre mostra a lista atualizada. Por isso, UC-01, UC-03 e UC-05 **incluem** UC-02. A mensagem de erro só aparece quando a entrada é inválida, então ela **estende** UC-01, UC-03 e UC-05. Uma versão editável está no arquivo `CasosDeUso.drawio`, em `docs/diagramas/`.

```mermaid
flowchart LR
    U["👤 Usuário"]
    subgraph SIS["Sistema Lista de Tarefas"]
        direction TB
        UC1(["UC-01 Adicionar tarefa"])
        UC2(["UC-02 Listar tarefas"])
        UC3(["UC-03 Concluir tarefa"])
        UC5(["UC-05 Excluir tarefa"])
        UC4(["UC-04 Exibir mensagem de erro"])
    end
    U --- UC1
    U --- UC2
    U --- UC3
    U --- UC5
    UC1 -. "«include»" .-> UC2
    UC3 -. "«include»" .-> UC2
    UC5 -. "«include»" .-> UC2
    UC4 -. "«extend»" .-> UC1
    UC4 -. "«extend»" .-> UC3
    UC4 -. "«extend»" .-> UC5
```

**Descrição dos atores**

| Ator | Descrição | Casos de uso associados |
|---|---|---|
| Usuário | Pessoa que usa o aplicativo para organizar as próprias tarefas. Não existe perfil de administrador. | UC-01, UC-02, UC-03, UC-05 |

**Lista de casos de uso**

| ID | Caso de uso | Ator(es) | Requisito(s) funcional(is) relacionado(s) |
|---|---|---|---|
| UC-01 | Adicionar tarefa | Usuário | RF-01 |
| UC-02 | Listar tarefas | Usuário | RF-02 |
| UC-03 | Concluir tarefa | Usuário | RF-03 |
| UC-04 | Exibir mensagem de erro (estende UC-01, UC-03 e UC-05 quando a entrada é inválida) | Usuário | RF-01, RF-03, RF-04 (RN-01, RN-02, RN-03) |
| UC-05 | Excluir tarefa | Usuário | RF-04 |

---

### 6.2 Visão arquitetural
O sistema é um **monolito**: um único executável, sem backend, que roda inteiro no dispositivo do usuário. Internamente, ele está organizado em **camadas** no estilo **MVC** (View → Controller → Service → Repository → arquivo) e em **pacote por funcionalidade** (tudo de "tarefas" fica no pacote `br.fatec.listatarefas.tarefas`). Escolhemos o monolito porque o escopo é pequeno, o uso é por uma pessoa em um dispositivo e um único executável é mais simples de desenvolver e entregar.

A camada de View tem duas telas:
- a **tela gráfica** (principal), em JavaFX: `TelaTarefas.fxml` com o controller `TelaTarefasFxController` e os estilos em `tarefas.css`;
- a **tela de console** (alternativa, argumento `--console`): `TelaTarefas`.

As duas usam os **mesmos comandos** do padrão GoF **Command** (seção 6.9). Os comandos falam com a tela pela interface `InteracaoUsuario`, então não sabem se ela é gráfica ou de console.

### 6.3 Diagrama de arquitetura (visão geral)

```mermaid
flowchart TD
    U["👤 Usuário"] --> G["Tela gráfica (principal)<br/>TelaTarefas.fxml + TelaTarefasFxController"]
    U -.-> K["Tela de console (--console)<br/>TelaTarefas"]
    G --> C["Comandos (padrão Command)<br/>NovaTarefa · ListarTarefas · ConcluirTarefa · ExcluirTarefa"]
    K --> C
    C --> CT["TarefaController"]
    CT --> S["TarefaService<br/>regras RN-01 a RN-04"]
    S --> R["TarefaRepository<br/>linha ⇄ Tarefa"]
    R --> L["ListaDeTarefas<br/>leitura/gravação"]
    L --> F[("Lista de tarefas.txt<br/>UTF-8, no dispositivo")]
```

O diagrama de containers do grupo (`Conteiners.drawio` e `Cliente.pdf`, em `docs/diagramas/`) mostra a mesma estrutura no nível de containers: o aplicativo Java e o arquivo `.txt`.

### 6.4 Componentes / Módulos

| Componente | Responsabilidade | Tecnologia |
|---|---|---|
| Inicialização (`Main`, `AppTarefas`) | `Main` escolhe a tela (`--console` ou gráfica) e monta Repository → Service → Controller; `AppTarefas` carrega o FXML e abre a janela | Java / JavaFX (`Application`, `FXMLLoader`) |
| Tela gráfica (`TelaTarefas.fxml`, `TelaTarefasFxController`, `tarefas.css`) | Cabeçalho com resumo, campo, lista de tarefas em cartões com selo Pendente/Concluída, botões Adicionar, Concluir e Excluir, mensagem de erro; cada botão executa um comando | JavaFX 21 + FXML + CSS |
| Tela de console (`TelaTarefas`, `InteracaoConsole`) | Menu numerado; lê o teclado na codificação do sistema | Java (`Scanner`/`PrintStream`) |
| Comandos (`ComandoMenu` e implementações) | Cada ação (adicionar, listar, concluir, excluir) encapsulada como objeto (padrão Command) | Java |
| `InteracaoUsuario` | Contrato entre os comandos e qualquer tela: pedir valor, mostrar erro, mostrar lista | Java (interface) |
| Controller (`TarefaController`) | Recebe as ações dos comandos e repassa ao Service, sem regra de negócio | Java |
| Service (`TarefaService`) | Regras de negócio RN-01 a RN-04, incluindo a exclusão | Java |
| Repository (`TarefaRepository`) | Converte linhas do arquivo em `Tarefa` e vice-versa | Java |
| Persistência (`ListaDeTarefas`) | Lê e grava as linhas do arquivo de texto | Java NIO (`Files`) |
| Model (`Tarefa`) | Entidade com id, descrição e status | Java |

Não há serviço de autenticação: o aplicativo é de usuário único e local.

### 6.5 Stack tecnológica

| Camada | Tecnologia / Ferramenta | Versão |
|---|---|---|
| Linguagem | Java | 17+ (testado em 21) |
| Front-end (tela gráfica) | JavaFX + FXML (`javafx-controls`, `javafx-fxml`) | 21.0.5 |
| Back-end | Não há (aplicativo local) | — |
| Banco de Dados | Arquivo de texto UTF-8 | — |
| Build / IDE | Maven / NetBeans (`javafx-maven-plugin` opcional) | 3.9 / 17+ (plugin 0.0.8) |
| Testes | JUnit Jupiter (JUnit 5) | 5.10.2 |
| Cobertura | JaCoCo | 0.8.12 |
| Infraestrutura / Cloud | Não há (execução local) | — |
| CI/CD | Não há; testes executados com `mvn test` | — |

### 6.6 Modelo de dados
Não há banco de dados. A única entidade persistida é a **Tarefa**, gravada no arquivo `Lista de tarefas.txt`, uma por linha, no formato `id|concluida|descricao`. Exemplo: `1|true|Estudar UML`.

```mermaid
erDiagram
    TAREFA {
        int id PK "maior id existente + 1 (RN-04)"
        boolean concluida "começa false"
        string descricao "1 a 100 caracteres, sem | e sem quebra de linha (RN-01, RN-02)"
    }
```

### 6.7 Diagrama de classes

```mermaid
classDiagram
    class Main {
        +main(String[] args)$ void
        ~criarController()$ TarefaController
    }
    class AppTarefas {
        +start(Stage janela) void
    }
    class TelaTarefasFxController {
        -TextField campoDescricao
        -ListView listaTarefas
        -Label mensagem
        -Label resumo
        -Button botaoConcluir
        -Button botaoExcluir
        -ComandoMenu comandoAdicionar
        -ComandoMenu comandoConcluir
        -ComandoMenu comandoExcluir
        ~initialize() void
        +inicializar(TarefaController controller) void
        ~adicionar() void
        ~concluir() void
        ~excluir() void
        +pedir(String rotulo) String
        +mostrarErro(String texto) void
        +mostrarTarefas(List~Tarefa~ tarefas) void
        ~textoResumo(List~Tarefa~ tarefas)$ String
    }
    class CelulaTarefa {
        #updateItem(Tarefa tarefa, boolean vazia) void
    }
    class TelaTarefas {
        -Scanner entrada
        -PrintStream saida
        -Map comandos
        -ComandoMenu listar
        +registrar(String tecla, ComandoMenu comando) void
        +iniciar() void
    }
    class InteracaoUsuario {
        <<interface>>
        +pedir(String rotulo) String
        +mostrarErro(String mensagem) void
        +mostrarTarefas(List~Tarefa~ tarefas) void
    }
    class InteracaoConsole {
        -Scanner entrada
        -PrintStream saida
    }
    class ComandoMenu {
        <<interface>>
        +descricao() String
        +executar() void
    }
    class NovaTarefaComando {
        -TarefaController controller
        -InteracaoUsuario tela
        -ComandoMenu listar
        +executar() void
    }
    class ListarTarefasComando {
        -TarefaController controller
        -InteracaoUsuario tela
        +executar() void
    }
    class ConcluirTarefaComando {
        -TarefaController controller
        -InteracaoUsuario tela
        -ComandoMenu listar
        +executar() void
    }
    class ExcluirTarefaComando {
        -TarefaController controller
        -InteracaoUsuario tela
        -ComandoMenu listar
        +executar() void
    }
    class TarefaController {
        -TarefaService service
        +adicionarTarefa(String descricao) void
        +carregarTarefas() List~Tarefa~
        +concluirTarefa(int id) void
        +excluirTarefa(int id) void
    }
    class TarefaService {
        +int TAMANHO_MAXIMO$
        -TarefaRepository repositorio
        +criar(String descricao) Tarefa
        +listarTodas() List~Tarefa~
        +concluir(int id) void
        +excluir(int id) void
        -proximoId() int
    }
    class TarefaRepository {
        -String SEPARADOR$
        -String arquivo
        -ListaDeTarefas lista
        +salvar(Tarefa tarefa) void
        +buscarTodas() List~Tarefa~
        +buscarPorId(int id) Tarefa
        +atualizar(Tarefa tarefa) void
        +remover(int id) void
        -paraLinha(Tarefa t) String
        -deLinha(String linha) Tarefa
    }
    class ListaDeTarefas {
        +String ARQUIVO_PADRAO$
        -String arquivo
        +lerLinhas() List~String~
        +gravarLinhas(List~String~ linhas) void
    }
    class Tarefa {
        -int id
        -String descricao
        -boolean concluida
        +marcarConcluida() void
        +getId() int
        +getDescricao() String
        +isConcluida() boolean
        +toString() String
    }

    Main ..> AppTarefas : abre (padrão)
    Main ..> TelaTarefas : abre (--console)
    AppTarefas ..> TelaTarefasFxController : carrega FXML
    InteracaoUsuario <|.. TelaTarefasFxController
    InteracaoUsuario <|.. InteracaoConsole
    TelaTarefas *-- "1" InteracaoConsole
    TelaTarefas "1" o-- "1..*" ComandoMenu : comandos
    TelaTarefasFxController "1" o-- "3" ComandoMenu : botões
    TelaTarefasFxController ..> CelulaTarefa : classe interna, cria as células
    ComandoMenu <|.. NovaTarefaComando
    ComandoMenu <|.. ListarTarefasComando
    ComandoMenu <|.. ConcluirTarefaComando
    ComandoMenu <|.. ExcluirTarefaComando
    NovaTarefaComando --> "1" InteracaoUsuario : tela
    ListarTarefasComando --> "1" InteracaoUsuario : tela
    ConcluirTarefaComando --> "1" InteracaoUsuario : tela
    ExcluirTarefaComando --> "1" InteracaoUsuario : tela
    NovaTarefaComando --> "1" TarefaController : receiver
    ListarTarefasComando --> "1" TarefaController : receiver
    ConcluirTarefaComando --> "1" TarefaController : receiver
    ExcluirTarefaComando --> "1" TarefaController : receiver
    NovaTarefaComando --> "1" ComandoMenu : listar
    ConcluirTarefaComando --> "1" ComandoMenu : listar
    ExcluirTarefaComando --> "1" ComandoMenu : listar
    TarefaController --> "1" TarefaService
    TarefaService --> "1" TarefaRepository
    TarefaService ..> Tarefa : cria
    TarefaRepository *-- "1" ListaDeTarefas
    TarefaRepository ..> Tarefa : converte
```

Notas:
- `comandos` é um `Map<String, ComandoMenu>` (tecla → comando). `listaTarefas` é um `ListView<Tarefa>`.
- `~` indica visibilidade de pacote: `adicionar()`, `concluir()` e `excluir()` são chamados pelos botões via FXML (`onAction="#adicionar"`), e os testes da tela os chamam diretamente. `initialize()` é chamado pelo `FXMLLoader`: configura a aparência da lista e desabilita Concluir e Excluir quando nada está selecionado.
- `CelulaTarefa` é uma classe interna de `TelaTarefasFxController` que desenha cada tarefa da lista: número, descrição (riscada se concluída) e selo Pendente/Concluída.
- `TarefaRepository` compõe `ListaDeTarefas`, e `TelaTarefas` compõe `InteracaoConsole`: as duas criam a instância no construtor.

**Descrição das principais classes**

| Classe | Responsabilidade | Requisito(s) relacionado(s) |
|---|---|---|
| Main | Ponto de entrada: abre a tela gráfica (ou o console com `--console`) e monta Repository → Service → Controller | RF-01 a RF-04 |
| AppTarefas | Carrega `TelaTarefas.fxml`, entrega o `TarefaController` ao controller da tela e mostra a janela | RF-02 |
| TelaTarefasFxController | Controller da tela gráfica e Invoker do Command: cada botão executa um comando; também é a `InteracaoUsuario` da tela gráfica e mostra o resumo no cabeçalho | RF-01 a RF-04, RNF-04, RNF-05 |
| CelulaTarefa | Aparência de cada tarefa na lista (cartão, selo de status, texto riscado se concluída) | RF-02, RF-03 |
| TelaTarefas | Tela de console e Invoker do Command (menu numerado) | RF-01, RF-02, RF-03, RNF-05 |
| InteracaoUsuario | Interface entre os comandos e qualquer tela | RNF-03 |
| InteracaoConsole | `InteracaoUsuario` do console (Scanner/PrintStream) | RNF-04, RNF-05 |
| ComandoMenu | Interface Command: contrato comum de todas as ações | RNF-03 |
| NovaTarefaComando | Comando "Nova tarefa" | RF-01, RN-01, RN-02 |
| ListarTarefasComando | Comando "Listar tarefas"; também é usado depois de adicionar e de concluir | RF-02 |
| ConcluirTarefaComando | Comando "Concluir tarefa"; trata seleção vazia e número inválido | RF-03, RN-03, RNF-05 |
| ExcluirTarefaComando | Comando "Excluir tarefa"; trata seleção vazia e número inválido | RF-04, RN-03, RNF-05 |
| TarefaController | Repassa as ações ao Service (Receiver dos comandos) | RF-01 a RF-04 |
| TarefaService | Regras de negócio, geração de id e exclusão | RN-01, RN-02, RN-03, RN-04 |
| TarefaRepository | Conversão entre linha do arquivo e `Tarefa`; remoção de linha | RF-01 a RF-04, RNF-02 |
| ListaDeTarefas | Leitura e gravação do arquivo em UTF-8 | RNF-02, RNF-04 |
| Tarefa | Entidade: id, descrição e status | RF-01, RF-03, RN-04 |

---

### 6.8 Diagrama de sequência

Os diagramas mostram a tela gráfica, que é a principal. No console, o fluxo é o mesmo a partir do comando: só muda quem é o Invoker (`TelaTarefas`) e a `InteracaoUsuario` (`InteracaoConsole`).

**Diagrama de sequência — UC-01: Adicionar tarefa (RF-01)**

```mermaid
sequenceDiagram
    actor U as Usuário
    participant T as TelaTarefasFxController
    participant N as NovaTarefaComando
    participant C as TarefaController
    participant S as TarefaService
    participant R as TarefaRepository
    participant L as ListaDeTarefas
    participant F as Lista de tarefas.txt

    U->>T: digita a descrição e clica em "Adicionar"
    T->>N: executar()
    N->>T: pedir("Descrição")
    T-->>N: texto do campo
    N->>C: adicionarTarefa(descricao)
    C->>S: criar(descricao)
    alt descrição válida (RN-01, RN-02)
        S->>R: buscarTodas() (cálculo do próximo id, RN-04)
        R->>L: lerLinhas()
        L->>F: lê o arquivo
        F-->>L: linhas
        L-->>R: List~String~
        R-->>S: List~Tarefa~
        S->>S: new Tarefa(id, descricao, false)
        S->>R: salvar(tarefa)
        R->>L: lerLinhas() + gravarLinhas(linhas)
        L->>F: grava com a nova linha
        S-->>C: Tarefa
        C-->>N: ok
        N->>N: listar.executar() (inclui UC-02)
        N->>T: mostrarTarefas(lista)
        T-->>U: lista atualizada e campo limpo
    else vazia, > 100 caracteres, com "|" ou quebra de linha
        S-->>C: IllegalArgumentException
        C-->>N: IllegalArgumentException
        N->>T: mostrarErro(mensagem)
        T-->>U: "Erro: ..." em vermelho (nada é gravado)
    end
```

**Diagrama de sequência — UC-02: Listar tarefas (RF-02)**

```mermaid
sequenceDiagram
    actor U as Usuário
    participant A as AppTarefas
    participant T as TelaTarefasFxController
    participant Li as ListarTarefasComando
    participant C as TarefaController
    participant S as TarefaService
    participant R as TarefaRepository
    participant L as ListaDeTarefas
    participant F as Lista de tarefas.txt

    U->>A: abre o aplicativo
    A->>T: carrega TelaTarefas.fxml e chama inicializar(controller)
    T->>Li: executar()
    Li->>C: carregarTarefas()
    C->>S: listarTodas()
    S->>R: buscarTodas()
    R->>L: lerLinhas()
    alt arquivo existe
        L->>F: lê todas as linhas
        F-->>L: linhas
    else arquivo não existe
        L-->>L: lista vazia
    end
    L-->>R: List~String~
    loop para cada linha não vazia
        R->>R: deLinha(linha) → Tarefa
    end
    R-->>S: List~Tarefa~
    S-->>C: List~Tarefa~
    C-->>Li: List~Tarefa~
    Li->>T: mostrarTarefas(lista)
    T-->>U: "id - [x] descrição" para cada tarefa (ou lista vazia)
```

**Diagrama de sequência — UC-03: Concluir tarefa (RF-03)**

```mermaid
sequenceDiagram
    actor U as Usuário
    participant T as TelaTarefasFxController
    participant Co as ConcluirTarefaComando
    participant C as TarefaController
    participant S as TarefaService
    participant R as TarefaRepository
    participant L as ListaDeTarefas
    participant F as Lista de tarefas.txt

    U->>T: seleciona a tarefa e clica em "Concluir"
    T->>Co: executar()
    Co->>T: pedir("Número da tarefa")
    T-->>Co: id da tarefa selecionada (ou vazio)
    alt nenhuma tarefa selecionada
        Co->>T: mostrarErro("selecione ou informe a tarefa.")
        T-->>U: mensagem de erro
    else tarefa selecionada
        Co->>C: concluirTarefa(id)
        C->>S: concluir(id)
        S->>R: buscarPorId(id)
        R->>L: lerLinhas()
        L->>F: lê o arquivo
        F-->>L: linhas
        R-->>S: Tarefa ou null
        alt tarefa encontrada
            S->>S: tarefa.marcarConcluida()
            S->>R: atualizar(tarefa)
            R->>L: gravarLinhas(linhas atualizadas)
            L->>F: reescreve o arquivo
            S-->>C: ok
            C-->>Co: ok
            Co->>Co: listar.executar() (inclui UC-02)
            Co->>T: mostrarTarefas(lista)
            T-->>U: a tarefa aparece com [x]
        else id inexistente (RN-03)
            S-->>C: IllegalArgumentException
            C-->>Co: IllegalArgumentException
            Co->>T: mostrarErro("Tarefa N não encontrada.")
            T-->>U: mensagem de erro
        end
    end
```

**Diagrama de sequência — UC-05: Excluir tarefa (RF-04)**

```mermaid
sequenceDiagram
    actor U as Usuário
    participant T as TelaTarefasFxController
    participant E as ExcluirTarefaComando
    participant C as TarefaController
    participant S as TarefaService
    participant R as TarefaRepository
    participant L as ListaDeTarefas
    participant F as Lista de tarefas.txt

    U->>T: seleciona a tarefa e clica em "Excluir"
    T->>E: executar()
    E->>T: pedir("Número da tarefa")
    T-->>E: id da tarefa selecionada (ou vazio)
    alt nenhuma tarefa selecionada
        E->>T: mostrarErro("selecione ou informe a tarefa.")
        T-->>U: mensagem de erro
    else tarefa selecionada
        E->>C: excluirTarefa(id)
        C->>S: excluir(id)
        S->>R: buscarPorId(id)
        R->>L: lerLinhas()
        L->>F: lê o arquivo
        F-->>L: linhas
        R-->>S: Tarefa ou null
        alt tarefa encontrada
            S->>R: remover(id)
            R->>L: gravarLinhas(linhas sem a tarefa)
            L->>F: reescreve o arquivo
            S-->>C: ok
            C-->>E: ok
            E->>E: listar.executar() (inclui UC-02)
            E->>T: mostrarTarefas(lista)
            T-->>U: a tarefa some da lista e o resumo é atualizado
        else id inexistente (RN-03)
            S-->>C: IllegalArgumentException
            C-->>E: IllegalArgumentException
            E->>T: mostrarErro("Tarefa N não encontrada.")
            T-->>U: mensagem de erro
        end
    end
```

---

### 6.9 Padrões de projeto (GoF) utilizados

| Padrão GoF | Categoria | Problema que resolve no projeto | Classes / arquivos envolvidos |
|---|---|---|---|
| Command | Comportamental | Cada ação (adicionar, listar, concluir, excluir) tem lógica própria de pedir dados, chamar o controller e tratar erro. Sem o padrão, essa lógica ficaria repetida na tela gráfica e na tela de console, e cada ação nova exigiria mudar as duas telas. | `tarefas/ComandoMenu.java`, `NovaTarefaComando.java`, `ListarTarefasComando.java`, `ConcluirTarefaComando.java`, `ExcluirTarefaComando.java`, `InteracaoUsuario.java`, `TelaTarefasFxController.java`, `TelaTarefas.java` |

#### Padrão 1 — Command

- **Categoria:** Comportamental
- **Intenção do padrão:** transformar um pedido (uma ação) em um objeto. Assim, quem dispara a ação (um botão, uma opção de menu) não precisa saber o que ela faz nem quem a executa de fato.
- **Motivação / contexto no projeto:** o aplicativo tem duas telas, a gráfica (botões) e a de console (menu numerado), que disparam as mesmas quatro ações. Cada ação é um objeto `ComandoMenu` com `executar()`. Os botões da tela gráfica e as teclas do console só chamam `executar()`. O comando pede o que precisa e mostra o resultado pela interface `InteracaoUsuario`, que cada tela implementa do seu jeito: a tela gráfica lê o campo e a seleção da lista; o console lê o teclado.
- **Alternativas consideradas:**
  - *Chamar o `TarefaController` direto em cada tela:* é mais simples, mas duplica a validação de entrada, o tratamento de erro e a atualização da lista nas duas telas.
  - *Strategy:* não se encaixa, porque as ações não são algoritmos intercambiáveis para a mesma tarefa, e sim ações diferentes disparadas pelo usuário.
  - *Observer (para atualizar a lista):* resolveria só a atualização da lista, não a organização das ações.
- **Participantes (mapeamento para o projeto):**

  | Papel no padrão | Classe no projeto |
  |---|---|
  | Command | `ComandoMenu` (interface) |
  | ConcreteCommand | `NovaTarefaComando`, `ListarTarefasComando`, `ConcluirTarefaComando`, `ExcluirTarefaComando` |
  | Invoker | `TelaTarefasFxController` (botões da tela gráfica) e `TelaTarefas` (menu do console) |
  | Receiver | `TarefaController` (quem realmente realiza a ação) |
  | Client | `TelaTarefasFxController.inicializar` e construtor de `TelaTarefas` (criam os comandos) |

- **Diagrama de classes do padrão:**

```mermaid
classDiagram
    class TelaTarefasFxController {
        -ComandoMenu comandoAdicionar
        -ComandoMenu comandoConcluir
        -ComandoMenu comandoExcluir
        ~adicionar() void
        ~concluir() void
        ~excluir() void
    }
    class TelaTarefas {
        -Map comandos
        +registrar(String tecla, ComandoMenu comando) void
        +iniciar() void
    }
    class ComandoMenu {
        <<interface>>
        +descricao() String
        +executar() void
    }
    class NovaTarefaComando {
        +executar() void
    }
    class ListarTarefasComando {
        +executar() void
    }
    class ConcluirTarefaComando {
        +executar() void
    }
    class ExcluirTarefaComando {
        +executar() void
    }
    class TarefaController {
        +adicionarTarefa(String descricao) void
        +carregarTarefas() List~Tarefa~
        +concluirTarefa(int id) void
        +excluirTarefa(int id) void
    }
    TelaTarefasFxController o-- ComandoMenu : Invoker (botões)
    TelaTarefas o-- ComandoMenu : Invoker (menu)
    ComandoMenu <|.. NovaTarefaComando
    ComandoMenu <|.. ListarTarefasComando
    ComandoMenu <|.. ConcluirTarefaComando
    ComandoMenu <|.. ExcluirTarefaComando
    NovaTarefaComando --> TarefaController : Receiver
    ListarTarefasComando --> TarefaController : Receiver
    ConcluirTarefaComando --> TarefaController : Receiver
    ExcluirTarefaComando --> TarefaController : Receiver
```

- **Trecho de código ilustrativo (código real do projeto):**

```java
// ComandoMenu.java — Command
public interface ComandoMenu {
    String descricao();
    void executar();
}

// TelaTarefasFxController.java — Invoker da tela gráfica
public void inicializar(TarefaController controller) {
    ComandoMenu listar = new ListarTarefasComando(controller, this);
    comandoAdicionar = new NovaTarefaComando(controller, this, listar);
    comandoConcluir = new ConcluirTarefaComando(controller, this, listar);
    comandoExcluir = new ExcluirTarefaComando(controller, this, listar);
    listar.executar();
}
@FXML void adicionar() { comandoAdicionar.executar(); }   // botão "Adicionar"
@FXML void concluir()  { comandoConcluir.executar(); }    // botão "Concluir"
@FXML void excluir()   { comandoExcluir.executar(); }     // botão "Excluir"

// NovaTarefaComando.java — ConcreteCommand: funciona com qualquer tela
public void executar() {
    try {
        controller.adicionarTarefa(tela.pedir("Descrição"));
        listar.executar();
    } catch (IllegalArgumentException e) {
        tela.mostrarErro(e.getMessage());
    }
}
```

- **Benefícios obtidos e consequências (trade-offs):**
  - *Benefícios:* a tela gráfica foi ligada reaproveitando os mesmos comandos do console, sem duplicar a validação nem o tratamento de erro. Uma ação nova entra com uma classe nova e fica disponível nas duas telas. Foi exatamente o que aconteceu com o **Excluir** (RF-04): bastou criar `ExcluirTarefaComando`, registrar a opção 4 no console com `registrar()` e ligar um botão na tela gráfica, sem alterar o laço do menu nem os outros comandos (CT-23, CT-36, CT-37). Os comandos são testados pelas duas telas (CT-20 a CT-23, CT-25 no console; CT-26 a CT-31 na tela gráfica).
  - *Consequências:* o projeto tem mais classes (interface `ComandoMenu`, quatro comandos, interface `InteracaoUsuario` e `InteracaoConsole`). Para poucas ações, isso é mais código do que chamar o controller direto; o custo se paga porque existem duas telas e o menu cresce (o Excluir já foi um exemplo; "editar" seria o próximo).

---

### 6.10 Decisões de arquitetura (ADR resumido)

| ID | Decisão | Contexto | Alternativas consideradas | Justificativa |
|---|---|---|---|---|
| ADR-01 | Monolito sem backend | Uso pessoal, um usuário, um dispositivo | Microsserviços; cliente + API | Escopo pequeno; um único executável é mais simples de construir, testar e entregar |
| ADR-02 | Persistir em arquivo `.txt` | O enunciado pede persistência simples e local | Banco local (SQLite); serialização Java | Simplicidade e arquivo legível por humanos (RNF-07); risco de desempenho aceito (R-02) |
| ADR-03 | Pacote por funcionalidade | Organização do código-fonte | Pacote por camada (`controller/`, `service/`…) | Tudo de "tarefas" fica junto, o que facilita encontrar e evoluir |
| ADR-04 | Padrão Command para as ações | Duas telas disparam as mesmas ações | Chamar o controller direto em cada tela; Strategy | Ações desacopladas das telas, testáveis e extensíveis (seção 6.9) |
| ADR-05 | Gravar o arquivo sempre em UTF-8 e ler o teclado do console na codificação do sistema | A codificação muda entre Windows e Linux, e o terminal do Windows/NetBeans envia o texto em Windows-1252 | Usar o padrão do Java (UTF-8) em tudo | Mesmo arquivo legível em qualquer sistema e acentos preservados (RNF-04, CT-19, CT-25) |
| ADR-06 | Tela gráfica JavaFX/FXML como principal; console como alternativa | Combinado do projeto: a Lista de Tarefas usa FXML | Só a tela gráfica | O console mantém os testes de menu (CT-20 a CT-25) e serve em máquinas sem interface gráfica |
| ADR-08 | Aparência da tela em um arquivo CSS (`tarefas.css`), ligado pelo FXML | A tela precisava ficar mais agradável sem misturar estilo com lógica | Estilos inline no FXML; estilos no código Java | Cores, bordas e espaçamentos ficam num só lugar e podem mudar sem recompilar a lógica; o FXML só descreve a estrutura |
| ADR-07 | `Main` não estende `Application`; ela chama `Application.launch(AppTarefas.class)` | O NetBeans (F6) roda o projeto pelo classpath, e uma classe principal que estende `Application` exige configurar módulos do JavaFX | Projeto modular (`module-info.java`) | Funciona no F6 sem configuração extra; o JavaFX só avisa "Unsupported JavaFX configuration", sem efeito prático |

### 6.11 Estrutura de pastas do projeto

```
ListaDeTarefas/
  pom.xml                                   build Maven (JavaFX 21, JUnit 5, JaCoCo)
  README.md
  src/main/java/br/fatec/listatarefas/
    Main.java                               escolhe a tela e monta Repository -> Service -> Controller
    AppTarefas.java                         abre a janela a partir do FXML
    tarefas/
      TelaTarefasFxController.java          tela gráfica: controller do FXML / Invoker (Command)
      TelaTarefas.java                      tela de console (--console) / Invoker (Command)
      InteracaoUsuario.java                 interface entre comandos e telas
      InteracaoConsole.java                 InteracaoUsuario do console
      ComandoMenu.java                      Command (interface)
      NovaTarefaComando.java                ConcreteCommand — RF-01
      ListarTarefasComando.java             ConcreteCommand — RF-02
      ConcluirTarefaComando.java            ConcreteCommand — RF-03
      ExcluirTarefaComando.java             ConcreteCommand — RF-04
      TarefaController.java                 Controller (Receiver)
      TarefaService.java                    Service — RN-01 a RN-04
      TarefaRepository.java                 Repository
      ListaDeTarefas.java                   leitura/gravação do .txt
      Tarefa.java                           Entity
  src/main/resources/br/fatec/listatarefas/tarefas/
    TelaTarefas.fxml                        layout da tela gráfica (JavaFX)
    tarefas.css                             estilos da tela gráfica
  src/test/java/br/fatec/listatarefas/tarefas/
    TarefaServiceTest.java                  CT-01 a CT-10, CT-33, CT-34
    TarefaRepositoryTest.java               CT-11 a CT-14, CT-35
    TarefaTest.java                         CT-15 a CT-17
    ListaDeTarefasTest.java                 CT-18, CT-19
    ComandosMenuTest.java                   CT-20 a CT-23, CT-25, CT-36
    TelaGraficaTest.java                    CT-26 a CT-31, CT-37 a CT-41
  docs/
    Documentacao_Lista_de_Tarefas.md        este documento
    diagramas/
      tela_principal.png                    captura da tela gráfica
      CasosDeUso.drawio                     casos de uso (Lista de Tarefas e Jogo da Forca)
      Conteiners.drawio, Cliente.pdf        containers
      classes_tarefas.pdf                   classes
      DiagramaSequencia-Colaboracao.pdf     sequência e comunicação
```

### 6.12 Integrações externas

| Sistema externo | Finalidade | Protocolo | Observações |
|---|---|---|---|
| — | — | — | Não há integrações externas. O aplicativo não acessa rede, APIs nem banco de dados; a única dependência é o sistema de arquivos local. |

---

## 7. Plano e Casos de Teste

### 7.1 Estratégia de testes

- **Testes unitários (JUnit 5):** cobrem as regras de negócio, a persistência, a entidade, os comandos pelo console e a tela gráfica. Ao todo são **6 classes de teste**.
- **Testes de integração leves:** em vez de mocks, cada teste usa os objetos reais (Service → Repository → arquivo) com um arquivo em uma pasta temporária criada pelo JUnit (`@TempDir`). Isso testa a gravação de verdade sem tocar no arquivo do usuário. O Mockito não foi necessário, porque não há dependência externa lenta ou difícil de reproduzir.
- **Testes da tela gráfica:** `TelaGraficaTest` carrega o `TelaTarefas.fxml` de verdade com o `FXMLLoader`, preenche o campo, seleciona itens e aciona os botões pelo thread do JavaFX. O CT-41 abre a janela de verdade para conferir como as tarefas aparecem. Esses testes precisam de uma tela (display): no NetBeans rodam normalmente, e em máquina sem tela são pulados com `assumeTrue`, sem falhar.
- **Teste de desempenho simples:** `assertTimeout` com 1.000 tarefas (RNF-01).
- **Testes manuais de sistema:** execução no Windows pelo NetBeans, no console (CT-24) e na tela gráfica (CT-32).
- **Cobertura de código:** medida com JaCoCo.

| Classe testada | Classe de teste (JUnit) | Cenários cobertos | Requisito(s) / Regra(s) relacionado(s) | Resultado |
|---|---|---|---|---|
| `TarefaService` | `TarefaServiceTest` | Caminho feliz (adicionar, listar, concluir, excluir); erro (descrição vazia/nula, caracteres proibidos, id inexistente ao concluir e ao excluir); valor limite (100 aceita / 101 rejeita); geração de id; desempenho; persistência após reabrir | RF-01 a RF-04, RN-01 a RN-04, RNF-01, RNF-02, RNF-06 | 17 execuções, 17 aprovadas |
| `TarefaRepository` | `TarefaRepositoryTest` | Formato da linha gravada; busca de id inexistente; atualização de uma só tarefa; linhas em branco; remoção de uma linha | RF-01, RF-03, RF-04, RN-03, RNF-02, RNF-07, R-01 | 5 aprovados |
| `Tarefa` | `TarefaTest` | Estado inicial; `marcarConcluida` idempotente; formato de exibição | RF-02, RF-03, RN-04 | 3 aprovados |
| `ListaDeTarefas` | `ListaDeTarefasTest` | Arquivo inexistente; gravação e leitura em UTF-8 com acentos | RNF-02, RNF-04, R-01 | 2 aprovados |
| `TelaTarefas` + comandos (console) | `ComandosMenuTest` | Fluxo completo pelo menu; opção inválida; número inválido e id inexistente; registro de comando novo; acentos digitados em Windows-1252; excluir pela opção 4 | RF-01, RF-04, RN-03, RNF-03, RNF-04, RNF-05 | 6 aprovados |
| `TelaTarefasFxController` + `TelaTarefas.fxml` + `tarefas.css` + comandos (tela gráfica) | `TelaGraficaTest` | Abrir a tela pelo FXML; adicionar; erro de campo vazio; selecionar e concluir; concluir sem seleção; acentos; excluir; excluir sem seleção; resumo do cabeçalho; botões desabilitados sem seleção; aparência das tarefas na janela (selos e texto riscado) | RF-01 a RF-04, RN-01, RN-03, RNF-04, RNF-05 | 11 aprovados |

**Recursos do JUnit utilizados**

| Recurso | Para que foi usado |
|---|---|
| `@Test` | Marca cada caso de teste |
| `@BeforeEach` | Cria um `TarefaService`/`TarefaRepository` novo, apontando para um arquivo limpo, antes de cada teste; na tela gráfica, carrega o FXML de novo |
| `@BeforeAll` | Inicia o JavaFX uma única vez para os testes da tela gráfica |
| `@TempDir` | Pasta temporária, apagada ao fim do teste, para o arquivo `.txt` |
| `@ParameterizedTest` + `@ValueSource` + `@NullAndEmptySource` | Roda o mesmo teste com várias entradas inválidas (`null`, `""`, `"   "`, `"\t"`, `"a\|b"`, quebras de linha) |
| `@DisplayName` | Mostra o ID do caso de teste (ex.: "CT-07 (RN-02): valor limite…") no relatório |
| `assertEquals`, `assertTrue`, `assertFalse`, `assertNull`, `assertNotNull` | Verificação dos resultados |
| `assertThrows` / `assertDoesNotThrow` | Verificação das exceções das regras de negócio |
| `assertAll` | Agrupa as verificações do estado inicial da `Tarefa` |
| `assertTimeout` | Limite de 1 s no teste de desempenho (RNF-01) |
| `assumeTrue` | Pula os testes da tela gráfica quando não há tela (display) |
| `Platform.runLater` + `CountDownLatch` (recursos do JavaFX, não do JUnit) | Executa as ações no thread da tela e espera terminar antes de verificar |

**Como os testes foram executados e resultado**
- No NetBeans: botão direito no projeto → **Test** (Alt+F6). Pela linha de comando: `mvn test`.
- Relatório de cobertura: gerado automaticamente em `target/site/jacoco/index.html` ao rodar `mvn test`.
- **Resultado (27/11/2026, Maven 3.9.11, JDK 21, Linux com tela virtual, `mvn test`):** 44 execuções (39 casos de teste automatizados, dos quais CT-02 e CT-06 são parametrizados), **44 aprovadas, 0 falhas, 0 erros**. Sem tela, os 11 testes da tela gráfica aparecem como pulados (*skipped*), e os outros 33 passam.
- **Defeito encontrado e corrigido:** no teste manual CT-24 (Windows, NetBeans, console), a descrição "ação" foi gravada como "a??o". O terminal envia o texto em Windows-1252, mas o programa lia como UTF-8 (padrão do Java a partir do JDK 18). A tela de console passou a ler o teclado na codificação do sistema, e o CT-25 garante que isso não volte a acontecer. Na tela gráfica o problema não existe (CT-31).
- **Cobertura (JaCoCo):** **86,1% das linhas** e **86,9% dos ramos (branches)**. Não são cobertos: `Main` e `AppTarefas` (só montam os objetos e abrem a janela real, verificados pelo CT-32), os `catch` de falha de leitura/gravação do disco, os construtores sem parâmetro e a detecção da codificação do terminal real (`charsetDoTeclado`, verificada pelo CT-24).

| Classe | Linhas cobertas | Ramos cobertos |
|---|---|---|
| TarefaService | 29/31 | 18/18 |
| TarefaRepository | 35/38 | 16/16 |
| Tarefa | 11/11 | 2/2 |
| ListaDeTarefas | 10/16 | 2/2 |
| TelaTarefasFxController | 39/39 | 12/12 |
| TelaTarefasFxController.CelulaTarefa | 25/25 | 9/10 |
| TelaTarefas | 32/39 | 5/10 |
| InteracaoConsole | 16/16 | 5/6 |
| NovaTarefaComando | 12/12 | — |
| ListarTarefasComando | 7/7 | — |
| ConcluirTarefaComando | 18/18 | 2/2 |
| ExcluirTarefaComando | 16/18 | 2/2 |
| TarefaController | 10/12 | — |
| AppTarefas | 0/12 | — |
| Main | 0/8 | 0/4 |

### 7.2 Ambientes de teste

| Ambiente | Finalidade | URL / Acesso |
|---|---|---|
| Desenvolvimento | Codificação e testes unitários na máquina de cada integrante (NetBeans 17+, JDK 17+) | Local — projeto Maven aberto no NetBeans |
| Homologação (QA) | Execução da suíte completa (`mvn test`) com relatório JaCoCo e testes manuais no Windows (CT-24, CT-32) | Local — pasta do projeto |
| Produção | Uso pelo usuário final | Local — NetBeans (Run, F6) ou `mvn javafx:run`; console com o argumento `--console`. Não há servidor |

### Convenção de ID
`CT-XX` (Caso de Teste número XX)

### 7.3 Casos de Teste

| ID | Requisito relacionado | Descrição / Cenário | Pré-condições | Passos | Resultado esperado | Status |
|---|---|---|---|---|---|---|
| CT-01 | RF-01 | Adicionar tarefa válida | Arquivo vazio | `criar("Estudar UML")` | Tarefa id 1, não concluída, 1 item na lista | Aprovado |
| CT-02 | RN-01 | Descrição vazia (parametrizado: `null`, `""`, `"   "`, `"\t"`) | Arquivo vazio | `criar(descricao)` | `IllegalArgumentException`; lista continua vazia | Aprovado |
| CT-03 | RF-02 | Listar tarefas persistidas na ordem | Arquivo vazio | Criar "A" e "B"; listar | 2 tarefas, "A" primeiro, "B" com id 2 | Aprovado |
| CT-04 | RF-03 | Concluir tarefa | Tarefa 1 cadastrada | `concluir(1)`; listar | Tarefa 1 concluída | Aprovado |
| RF-04 | Excluir tarefa | CT-33, CT-35, CT-36, CT-37 | `ExcluirTarefaComando.java`, `TelaTarefasFxController.java`, `TelaTarefas.java`, `TarefaController.java`, `TarefaService.java` (`excluir`), `TarefaRepository.java` (`remover`) | Concluído | Aprovado |
| CT-05 | RN-03 | Concluir id inexistente | Arquivo vazio | `concluir(99)` | `IllegalArgumentException` | Aprovado |
| CT-06 | RN-02, RNF-06 | Caracteres proibidos (parametrizado: `a\|b`, `\n`, `\r`) | Arquivo vazio | `criar(descricao)` | `IllegalArgumentException` | Aprovado |
| CT-07 | RN-02 | Valor limite de tamanho | Arquivo vazio | `criar` com 100 e com 101 caracteres | 100 aceita; 101 rejeita; 1 tarefa na lista | Aprovado |
| CT-08 | RN-04 | Id = maior existente + 1 | Tarefas com ids 1 e 5 | `criar("C")` | Nova tarefa com id 6, não concluída | Aprovado |
| CT-09 | RNF-01 | Desempenho com 1.000 tarefas | Arquivo com 1.000 linhas | Listar, adicionar e concluir | Tudo em ≤ 1 s | Aprovado |
| CT-10 | RNF-02 | Dados após reabrir | Arquivo vazio | Criar e concluir "A"; criar novo Service no mesmo arquivo; listar | "A" presente e concluída | Aprovado |
| CT-11 | RF-01, RNF-02, RNF-07 | Formato gravado no arquivo | Arquivo vazio | `salvar(Tarefa(1,"Estudar UML",false))`; ler o arquivo | Linha `1\|false\|Estudar UML`; leitura devolve a mesma tarefa | Aprovado |
| CT-12 | RN-03 | Buscar id inexistente | Tarefa 1 cadastrada | `buscarPorId(2)` e `buscarPorId(1)` | `null` e tarefa encontrada | Aprovado |
| CT-13 | RF-03 | Atualizar altera só a tarefa informada | Tarefas 1 e 2 pendentes | Concluir 2; `atualizar` | 1 pendente, 2 concluída, 2 tarefas no total | Aprovado |
| CT-14 | R-01, RNF-06 | Linhas em branco no arquivo | Arquivo com linhas vazias | `buscarTodas()` | Só as 2 tarefas válidas | Aprovado |
| CT-15 | RN-04 | Estado inicial da tarefa | — | `new Tarefa(3, "Ler capítulo 2", false)` | Id, descrição e status corretos | Aprovado |
| CT-16 | RF-03 | `marcarConcluida` idempotente | Tarefa pendente | Chamar `marcarConcluida()` duas vezes | Tarefa concluída, sem erro | Aprovado |
| CT-17 | RF-02 | Formato de exibição | — | `toString()` de tarefa pendente e concluída | `1 - [ ] A` e `2 - [x] B` | Aprovado |
| CT-18 | R-01, RNF-02 | Arquivo inexistente | Arquivo não existe | `lerLinhas()` | Lista vazia, sem exceção | Aprovado |
| CT-19 | RNF-04 | Acentos em UTF-8 | — | Gravar e ler linhas com "Revisão", "Ação nº 2" | Linhas idênticas às gravadas | Aprovado |
| CT-20 | RF-01 | Nova tarefa pelo menu do console (Command) | Arquivo vazio | Digitar `1`, "Comprar pão", `0` | Lista mostra `1 - [ ] Comprar pão` | Aprovado |
| CT-21 | RNF-05 | Opção inválida no menu do console | — | Digitar `9`, `0` | "Opção inválida." e o app continua até "Até logo!" | Aprovado |
| CT-22 | RNF-05, RN-03 | Concluir com entrada inválida pelo console | Arquivo vazio | Digitar `3`, "abc", `3`, "42", `0` | "informe um número válido" e "Tarefa 42 não encontrada" | Aprovado |
| CT-23 | RNF-03 | Novo comando sem alterar o Invoker do console | — | `registrar("4", comando)`; digitar `4`, `0` | Menu mostra "4 - Comando de teste" e o comando é executado | Aprovado |
| CT-24 | RNF-04 | Execução manual do console no Windows | Windows com JDK 17+ e NetBeans; argumento `--console`; sem `Lista de tarefas.txt` | Run (F6), cadastrar "Ação", concluir, fechar e reabrir | Tarefa "Ação" aparece concluída, com acento correto | A executar (1ª execução reprovada: "a??o"; corrigido, ver CT-25) |
| CT-25 | RNF-04 | Acentos digitados em Windows-1252 no console | Arquivo vazio | Tela de console com entrada em Windows-1252: digitar `1`, "Ação", `0` | Tarefa gravada como "Ação" | Aprovado |
| CT-26 | RF-02 | Tela gráfica abre a partir do FXML | Arquivo vazio | Carregar `TelaTarefas.fxml` e inicializar | Controller criado; lista vazia; sem mensagem | Aprovado |
| CT-27 | RF-01 | Adicionar pela tela gráfica | Tela aberta | Digitar "Estudar UML" e clicar em Adicionar | Lista mostra `1 - [ ] Estudar UML`; campo limpo | Aprovado |
| CT-28 | RN-01, RNF-05 | Adicionar com o campo vazio | Tela aberta | Clicar em Adicionar | "Erro: A descrição da tarefa não pode ser vazia."; lista vazia | Aprovado |
| CT-29 | RF-03 | Concluir pela tela gráfica | Tela com a tarefa "A" | Selecionar "A" e clicar em Concluir | Lista mostra `1 - [x] A` | Aprovado |
| CT-30 | RN-03, RNF-05 | Concluir sem seleção | Tela aberta | Acionar Concluir sem tarefa selecionada | "Erro: selecione ou informe a tarefa." | Aprovado |
| CT-31 | RNF-04 | Acentos na tela gráfica | Tela aberta | Adicionar "Revisão de Programação" | Lista mostra a descrição com acentos | Aprovado |
| CT-32 | RF-01 a RF-04, RNF-04 | Execução manual da tela gráfica no Windows | Windows com JDK 17+ e NetBeans; sem `Lista de tarefas.txt` | Run (F6); adicionar "Ação" e "Teste"; selecionar "Ação" e clicar em Concluir; selecionar "Teste" e clicar em Excluir; fechar e reabrir | A janela abre; só "Ação" aparece, riscada e com selo "Concluída", com acento correto | A executar |
| CT-33 | RF-04 | Excluir pelo Service | Tarefas A, B, C | `excluir(2)`; listar | Restam A e C, nessa ordem | Aprovado |
| CT-34 | RN-03 | Excluir id inexistente | Tarefa A | `excluir(99)` | `IllegalArgumentException`; A continua | Aprovado |
| CT-35 | RF-04 | Remover linha do arquivo | Tarefas 1, 2, 3 | `remover(2)`; ler o arquivo | Linhas `1\|false\|A` e `3\|false\|C` | Aprovado |
| CT-36 | RF-04, RN-03 | Excluir pelo console (opção 4) | Arquivo vazio | Cadastrar A e B; `4`, `1`; `4`, `7`; `0` | Só B resta; menu mostra "4 - Excluir tarefa"; "Erro: Tarefa 7 não encontrada." | Aprovado |
| CT-37 | RF-04 | Excluir pela tela gráfica | Tela com A e B | Selecionar A e clicar em Excluir | Lista mostra só `2 - [ ] B` | Aprovado |
| CT-38 | RN-03, RNF-05 | Excluir sem seleção | Tela aberta | Acionar Excluir sem tarefa selecionada | "Erro: selecione ou informe a tarefa." visível | Aprovado |
| CT-39 | RF-02 | Resumo no cabeçalho | Tela aberta | Ver resumo; adicionar A e B; concluir A | "Nenhuma tarefa" e depois "2 tarefas · 1 concluída · 1 pendente" | Aprovado |
| CT-40 | RNF-05 | Botões dependem da seleção | Tela aberta | Ver Concluir/Excluir sem seleção; adicionar e selecionar | Desabilitados sem seleção; habilitados com seleção | Aprovado |
| CT-41 | RF-02, RF-03 | Aparência das tarefas na janela | Tela com A (concluída) e B | Abrir a janela e renderizar a lista | Selos "Concluída" e "Pendente"; 1 descrição riscada | Aprovado |

---

## 8. Matriz de Rastreabilidade (Requisitos x Testes x Código-fonte)

> Caminhos relativos a `src/main/java/br/fatec/listatarefas/tarefas/`, exceto quando indicado.

| Requisito (RF/RNF/RN) | Descrição resumida | Caso(s) de Teste | Arquivo(s) / Módulo de código | Status de implementação | Status de teste |
|---|---|---|---|---|---|
| RF-01 | Adicionar tarefa | CT-01, CT-11, CT-20, CT-27 | `NovaTarefaComando.java`, `TelaTarefasFxController.java`, `TarefaController.java`, `TarefaService.java`, `TarefaRepository.java` | Concluído | Aprovado |
| RF-02 | Listar tarefas | CT-03, CT-17, CT-26, CT-39, CT-41 | `ListarTarefasComando.java`, `TelaTarefasFxController.java`, `TarefaService.java`, `TarefaRepository.java`; `../AppTarefas.java` | Concluído | Aprovado |
| RF-03 | Concluir tarefa | CT-04, CT-13, CT-16, CT-29, CT-41 | `ConcluirTarefaComando.java`, `TelaTarefasFxController.java`, `TarefaService.java`, `TarefaRepository.java`, `Tarefa.java` | Concluído | Aprovado |
| RNF-01 | ≤ 1 s com 1.000 tarefas | CT-09 | `TarefaRepository.java`, `ListaDeTarefas.java` | Concluído | Aprovado |
| RNF-02 | Persistência entre execuções | CT-10, CT-11, CT-18 | `ListaDeTarefas.java`, `TarefaRepository.java` | Concluído | Aprovado |
| RNF-03 | Modularidade / testabilidade | CT-23, CT-36 (+ cobertura 86,1%) | pacote `tarefas/`, `ComandoMenu.java`, `InteracaoUsuario.java` | Concluído | Aprovado |
| RNF-04 | Portabilidade / acentos | CT-19, CT-24, CT-25, CT-31, CT-32 | `ListaDeTarefas.java`, `TelaTarefas.java` (`charsetDoTeclado`), `TelaTarefasFxController.java` | Concluído | Em execução (CT-19, CT-25 e CT-31 aprovados; CT-24 e CT-32 manuais a executar) |
| RNF-05 | Proteção contra erros | CT-21, CT-22, CT-28, CT-30, CT-38, CT-40 | `TelaTarefas.java`, `TelaTarefasFxController.java`, `NovaTarefaComando.java`, `ConcluirTarefaComando.java` | Concluído | Aprovado |
| RNF-06 | Integridade do arquivo | CT-06, CT-14 | `TarefaService.java`, `TarefaRepository.java` | Concluído | Aprovado |
| RNF-07 | Arquivo de texto legível | CT-11 | `TarefaRepository.java` | Concluído | Aprovado |
| RNF-08 | Completude funcional | CT-01, CT-03, CT-04, CT-27, CT-29, CT-33, CT-37 | todos os acima | Concluído | Aprovado |
| RNF-L03 | Minimização de dados (LGPD) | CT-11 | `TarefaRepository.java` (3 campos) | Concluído | Aprovado |
| RNF-L09 | Privacy by default (LGPD) | — (inspeção: sem integração externa, seção 6.12) | projeto inteiro | Concluído | Aprovado por inspeção |
| RN-01 | Descrição não vazia | CT-02, CT-28 | `TarefaService.java` (`criar`) | Concluído | Aprovado |
| RN-02 | Até 100 caracteres, sem `\|` e sem quebra de linha | CT-06, CT-07 | `TarefaService.java` (`criar`) | Concluído | Aprovado |
| RN-03 | Concluir ou excluir só tarefa existente | CT-05, CT-12, CT-22, CT-30, CT-34, CT-36, CT-38 | `TarefaService.java` (`concluir`, `excluir`), `TarefaRepository.java` (`buscarPorId`), `ConcluirTarefaComando.java`, `ExcluirTarefaComando.java` | Concluído | Aprovado |
| RN-04 | Id = maior + 1, nasce não concluída | CT-08, CT-15 | `TarefaService.java` (`proximoId`), `Tarefa.java` | Concluído | Aprovado |

**Legenda — Status de implementação:** Não iniciado / Em desenvolvimento / Concluído / Bloqueado
**Legenda — Status de teste:** Pendente / Em execução / Aprovado / Reprovado

Os IDs dos casos de teste aparecem no `@DisplayName` de cada método JUnit (ex.: `"CT-07 (RN-02): ..."`). Assim, o relatório do NetBeans/Maven liga cada execução ao requisito correspondente.

---

## 9. Glossário

| Termo | Definição |
|---|---|
| Tarefa | Item da lista, com número (id), descrição e status (pendente ou concluída) |
| MVC | Padrão que separa Model (dados), View (tela) e Controller (ações) |
| Pacote por funcionalidade | Organização em que tudo de uma funcionalidade fica no mesmo pacote |
| Monolito | Sistema construído e executado como um único programa |
| GoF | *Gang of Four*: os quatro autores do livro *Design Patterns* (1994), que catalogou 23 padrões de projeto |
| Command | Padrão GoF comportamental que transforma uma ação em objeto |
| Invoker / Receiver | No Command: quem dispara o comando (botões da `TelaTarefasFxController` ou menu da `TelaTarefas`) / quem realiza a ação (`TarefaController`) |
| JavaFX | Biblioteca Java para telas gráficas |
| FXML | Arquivo XML que descreve o layout de uma tela JavaFX; aqui, `TelaTarefas.fxml` |
| CSS (JavaFX) | Folha de estilos da tela (cores, bordas, espaçamento); aqui, `tarefas.css` |
| JUnit | Framework de testes unitários para Java |
| JaCoCo | Ferramenta que mede a cobertura de código dos testes Java |
| Maven | Ferramenta de build e de gestão de dependências usada pelo projeto |
| UTF-8 | Codificação de caracteres que preserva acentos em qualquer sistema operacional |
| RF / RNF / RN / CT / UC | Requisito Funcional / Requisito Não Funcional / Regra de Negócio / Caso de Teste / Caso de Uso |
| LGPD | Lei Geral de Proteção de Dados Pessoais (Lei nº 13.709/2018) |

---

## 10. Anexos e Referências

- Tela gráfica: `src/main/resources/br/fatec/listatarefas/tarefas/TelaTarefas.fxml` (abre no Scene Builder); captura em `docs/diagramas/tela_principal.png`.

![Tela principal da Lista de Tarefas](diagramas/tela_principal.png)

- Link para repositório de código: —
- Link para backlog / board: —
- Diagramas complementares, na pasta `docs/diagramas/`: `Conteiners.drawio` e `Cliente.pdf` (containers), `CasosDeUso.drawio` (casos de uso, versão editável), `classes_tarefas.pdf` (classes) e `DiagramaSequencia-Colaboracao.pdf` (sequência e comunicação).
- Documentos de referência:
  - GAMMA, E.; HELM, R.; JOHNSON, R.; VLISSIDES, J. *Padrões de Projeto: soluções reutilizáveis de software orientado a objetos*. Porto Alegre: Bookman, 2000.
  - ISO/IEC 25010:2011. *Systems and software engineering — Systems and software Quality Requirements and Evaluation (SQuaRE) — System and software quality models*.
  - BRASIL. Lei nº 13.709, de 14 de agosto de 2018. Lei Geral de Proteção de Dados Pessoais (LGPD).
  - JUnit 5 User Guide. Disponível em: https://junit.org/junit5/docs/current/user-guide/
  - OpenJFX — JavaFX Documentation. Disponível em: https://openjfx.io/
  - ROSA, A. C. P.; SANTOS, P. C. *Arquitetura de Software: fundamentos e práticas para desenvolvimento eficiente*. IFSULDEMINAS.
  - AMARAL, O.; CARVALHO, M. *Arquitetura de Micro Serviços: uma Comparação com Sistemas Monolíticos*. UFPB.
