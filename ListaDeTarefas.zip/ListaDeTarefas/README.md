# Lista de Tarefas (NetBeans / Maven)

Implementação em Java do diagrama de classes, dos diagramas de sequência/comunicação e do modelo de documentação do grupo.

## Abrir no NetBeans
1. **File → Open Project…** e selecione a pasta `ListaDeTarefas` (o ícone de Maven aparece).
2. **Run Project (F6)**. A classe principal é `br.fatec.listatarefas.Main`.
3. **Test Project (Alt+F6)** roda os testes JUnit (`TarefaServiceTest`).

Requisitos: JDK 17 ou superior e NetBeans 17+ (o Maven já vem embutido). Na primeira execução o NetBeans baixa o JUnit.

O arquivo `Lista de tarefas.txt` é criado na pasta do projeto, no primeiro cadastro (formato `id|concluida|descricao`).

## Testes e cobertura
- NetBeans: **Test Project (Alt+F6)**. Linha de comando: `mvn test`.
- 5 classes de teste (CT-01 a CT-23 e CT-25; o CT-24 é manual). Relatório de cobertura JaCoCo em `target/site/jacoco/index.html`.

## Estrutura (pacote por funcionalidade + MVC + padrão Command)
```
src/main/java/br/fatec/listatarefas/
  Main.java                      monta Repository -> Service -> Controller -> Tela
  tarefas/
    TelaTarefas.java             View de console / Invoker (Command)
    ComandoMenu.java             Command (interface)
    NovaTarefaComando.java       ConcreteCommand  (RF-01)
    ListarTarefasComando.java    ConcreteCommand  (RF-02)
    ConcluirTarefaComando.java   ConcreteCommand  (RF-03)
    TarefaController.java        Controller (Receiver)
    TarefaService.java           Service (regras RN-01..RN-04)
    TarefaRepository.java        Repository
    ListaDeTarefas.java          lê/grava o arquivo .txt
    Tarefa.java                  Entity
src/test/java/br/fatec/listatarefas/tarefas/
  TarefaServiceTest, TarefaRepositoryTest, TarefaTest,
  ListaDeTarefasTest, ComandosMenuTest
docs/Documentacao_Lista_de_Tarefas.md      documentação no modelo V2 da disciplina
```
