# Lista de Tarefas (NetBeans / Maven)

Implementação em Java do diagrama de classes, dos diagramas de sequência/comunicação e do modelo de documentação do grupo.

## Abrir no NetBeans
1. **File → Open Project…** e selecione a pasta `ListaDeTarefas` (o ícone de Maven aparece).
2. **Run Project (F6)**: abre a **tela gráfica** (JavaFX, `TelaTarefas.fxml` + `tarefas.css`): adicionar, concluir e excluir tarefas. A classe principal é `br.fatec.listatarefas.Main`.
   - Tela de console: em *Project Properties → Run → Arguments*, informe `--console`.
   - Pela linha de comando também funciona: `mvn javafx:run`.
3. **Test Project (Alt+F6)** roda os testes JUnit.

Requisitos: JDK 17 ou superior e NetBeans 17+ (o Maven já vem embutido). Na primeira execução o NetBeans baixa o JavaFX e o JUnit.

O arquivo `Lista de tarefas.txt` é criado na pasta do projeto, no primeiro cadastro (formato `id|concluida|descricao`).

## Testes e cobertura
- NetBeans: **Test Project (Alt+F6)**. Linha de comando: `mvn test`.
- 6 classes de teste (CT-01 a CT-23, CT-25 a CT-31 e CT-33 a CT-41; CT-24 e CT-32 são manuais). Os testes da tela gráfica (`TelaGraficaTest`) precisam de monitor; sem tela eles são pulados. Relatório de cobertura JaCoCo em `target/site/jacoco/index.html`.

## Estrutura (pacote por funcionalidade + MVC + padrão Command)
```
src/main/java/br/fatec/listatarefas/
  Main.java                      abre a tela gráfica (ou o console com --console)
  AppTarefas.java                carrega o FXML e abre a janela
  tarefas/
    TelaTarefasFxController.java tela gráfica: controller do FXML / Invoker (Command)
    TelaTarefas.java             tela de console / Invoker (Command)
    InteracaoUsuario.java        interface entre comandos e telas
    InteracaoConsole.java        InteracaoUsuario do console
    ComandoMenu.java             Command (interface)
    NovaTarefaComando.java       ConcreteCommand  (RF-01)
    ListarTarefasComando.java    ConcreteCommand  (RF-02)
    ConcluirTarefaComando.java   ConcreteCommand  (RF-03)
    ExcluirTarefaComando.java    ConcreteCommand  (RF-04)
    TarefaController.java        Controller (Receiver)
    TarefaService.java           Service (regras RN-01..RN-04)
    TarefaRepository.java        Repository
    ListaDeTarefas.java          lê/grava o arquivo .txt
    Tarefa.java                  Entity
src/main/resources/br/fatec/listatarefas/tarefas/
  TelaTarefas.fxml               layout da tela gráfica
  tarefas.css                    estilos da tela gráfica
src/test/java/br/fatec/listatarefas/tarefas/
  TarefaServiceTest, TarefaRepositoryTest, TarefaTest,
  ListaDeTarefasTest, ComandosMenuTest, TelaGraficaTest
docs/Documentacao_Lista_de_Tarefas.md      documentação no modelo V2 da disciplina
docs/diagramas/                            tela, casos de uso, containers, classes, sequência/comunicação
```
